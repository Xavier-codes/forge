/**
 * Forge — AI-native Product Management System
 * Core type definitions
 */

// ─── Signal Types ────────────────────────────────────────────────────────────

export type SignalSource = 'interview' | 'intercom' | 'g2' | 'sales_call' | 'survey' | 'support' | 'nps' | 'slack' | 'csv' | 'amplitude';
export type SignalSentiment = 'pain' | 'request' | 'delight' | 'neutral' | 'churn_risk';
export type SignalPriority = 'critical' | 'high' | 'medium' | 'low';

export interface Signal {
  id: string;
  sourceType: SignalSource;
  sourceRef?: string; // e.g. Intercom ticket ID
  rawText: string;
  normalizedText: string;
  sentiment: SignalSentiment;
  themes: string[];
  productArea?: string;
  userId?: string;
  userSegment?: string; // 'enterprise' | 'smb' | 'free' etc.
  createdAt: Date;
  weight: number; // 0–1, boosted by user plan, recency, etc.
}

// ─── Feature Candidate ───────────────────────────────────────────────────────

export type EffortEstimate = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type ImpactCategory = 'retention' | 'acquisition' | 'revenue' | 'nps' | 'efficiency';

export interface FeatureCandidate {
  id: string;
  title: string;
  description: string;
  evidenceSummary: string;         // Why this, in plain language
  supportingSignals: Signal[];
  productArea: string;
  impactCategory: ImpactCategory;
  impactScore: number;             // 0–100 composite
  effortEstimate: EffortEstimate;
  riskScore: number;               // 0–100 (higher = riskier)
  priorityScore: number;           // Computed: impact / effort × (1 - risk)
  uiChanges?: UIChangeSuggestion[];
  relatedTickets?: DevTicket[];
  createdAt: Date;
}

// ─── UI Change Suggestions ───────────────────────────────────────────────────

export type UIChangeType = 'add_button' | 'add_screen' | 'modify_flow' | 'add_empty_state' | 'add_modal' | 'add_nav_item';

export interface UIChangeSuggestion {
  type: UIChangeType;
  location: string;           // e.g. "Settings > Integrations"
  description: string;
  rationale: string;
  beforeState?: string;
  afterState?: string;
}

// ─── Dev Tickets ─────────────────────────────────────────────────────────────

export type TicketType = 'feature' | 'research' | 'data_model' | 'api' | 'ui' | 'infra' | 'backend';
export type TicketStatus = 'backlog' | 'todo' | 'in_progress' | 'in_review' | 'done';
export type TicketLabel = 'ui' | 'backend' | 'data' | 'research' | 'infra' | 'api';

export interface DevTicket {
  id: string;
  featureId: string;
  type: TicketType;
  title: string;
  description: string;
  acceptanceCriteria: string[];
  labels: TicketLabel[];
  estimatedHours?: number;
  status: TicketStatus;
  codePointers?: CodePointer[];
  createdAt: Date;
}

export interface CodePointer {
  file: string;
  description: string;
  suggestedChange: string;
}

// ─── Analysis Request / Response ─────────────────────────────────────────────

export interface AnalysisQuery {
  question: string;
  workspaceId: string;
  signalIds?: string[];           // Optional: limit to specific signals
  productAreas?: string[];        // Optional: focus on specific areas
  maxCandidates?: number;
}

export interface AnalysisResult {
  query: AnalysisQuery;
  candidates: FeatureCandidate[];
  signalCount: number;
  themesSurfaced: string[];
  processingMs: number;
  modelVersion: string;
  createdAt: Date;
}

// ─── Workspace & Ingestion ───────────────────────────────────────────────────

export interface Workspace {
  id: string;
  name: string;
  slug: string;
  signals: Signal[];
  features: FeatureCandidate[];
  tickets: DevTicket[];
  sources: DataSource[];
  createdAt: Date;
}

export interface DataSource {
  id: string;
  type: SignalSource;
  name: string;
  lastSyncAt?: Date;
  signalCount: number;
  config?: Record<string, string>;
}

// ─── Ingest Results ──────────────────────────────────────────────────────────

export interface IngestResult {
  sourceType: SignalSource;
  signalsExtracted: number;
  signalsParsed: Signal[];
  errors: string[];
  durationMs: number;
}
