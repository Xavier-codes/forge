/**
 * Forge Analysis Engine
 *
 * The main orchestrator. Takes an AnalysisQuery + a set of signals,
 * and returns a ranked AnalysisResult with feature candidates and dev tickets.
 */

import { Signal, FeatureCandidate, AnalysisQuery, AnalysisResult, EffortEstimate } from '../types';
import {
  computeImpactScore,
  computeReachScore,
  computeRiskScore,
  computePriorityScore,
  inferImpactCategory,
  extractThemes,
  rankCandidates,
  deduplicateSignals,
} from './scorer';
import { generateTickets } from './ticketGenerator';
import { generateId, groupBy } from './utils';

// ─── Feature Area Clustering ──────────────────────────────────────────────────

/**
 * Cluster signals into feature areas based on shared themes.
 * Returns a map of productArea → Signal[].
 */
function clusterSignalsByArea(signals: Signal[]): Record<string, Signal[]> {
  const AREA_THEME_MAP: Record<string, string[]> = {
    'Onboarding': ['onboarding', 'bulk-import'],
    'Notifications': ['notifications'],
    'Integrations': ['slack-integration', 'api-access'],
    'Analytics': ['reporting', 'search'],
    'Performance': ['performance'],
    'Mobile': ['mobile'],
    'Collaboration': ['collaboration'],
  };

  const clusters: Record<string, Signal[]> = {};
  const assigned = new Set<string>();

  for (const [area, themes] of Object.entries(AREA_THEME_MAP)) {
    const areaSignals = signals.filter(sig =>
      sig.themes.some(t => themes.includes(t))
    );
    if (areaSignals.length > 0) {
      clusters[area] = areaSignals;
      areaSignals.forEach(s => assigned.add(s.id));
    }
  }

  // Put unassigned signals into a catch-all
  const unassigned = signals.filter(s => !assigned.has(s.id));
  if (unassigned.length > 0) {
    clusters['General'] = unassigned;
  }

  return clusters;
}

// ─── Effort Heuristic ─────────────────────────────────────────────────────────

function estimateEffort(signals: Signal[], area: string): EffortEstimate {
  const themeCount = new Set(signals.flatMap(s => s.themes)).size;
  if (area === 'Integrations' || themeCount >= 4) return 'lg';
  if (themeCount >= 3) return 'md';
  if (signals.length >= 10) return 'md';
  if (signals.length >= 5) return 'sm';
  return 'sm';
}

// ─── Title Generator ─────────────────────────────────────────────────────────

const AREA_TITLES: Record<string, Record<string, string>> = {
  'Onboarding': {
    'bulk-import': 'Bulk CSV import for account setup',
    'onboarding': 'Streamlined first-run onboarding flow',
  },
  'Notifications': {
    'notifications': 'Weekly digest email + in-app notification centre',
  },
  'Integrations': {
    'slack-integration': 'Slack & Microsoft Teams notification integration',
    'api-access': 'Public API + webhook event system',
  },
  'Analytics': {
    'reporting': 'Advanced analytics dashboard with export',
    'search': 'Global search with filters',
  },
};

function pickTitle(area: string, signals: Signal[]): string {
  const areaMap = AREA_TITLES[area];
  if (areaMap) {
    for (const theme of signals.flatMap(s => s.themes)) {
      if (areaMap[theme]) return areaMap[theme];
    }
  }
  return `${area} improvements`;
}

// ─── Main Analyzer ───────────────────────────────────────────────────────────

export function analyze(query: AnalysisQuery, allSignals: Signal[]): AnalysisResult {
  const t0 = Date.now();

  // 1. Deduplicate signals
  const signals = deduplicateSignals(allSignals);

  // 2. Cluster into feature areas
  const clusters = clusterSignalsByArea(signals);

  // 3. Build and score a FeatureCandidate per cluster
  const candidates: FeatureCandidate[] = [];

  for (const [area, areaSignals] of Object.entries(clusters)) {
    if (areaSignals.length === 0) continue;

    const impactScore = computeImpactScore(areaSignals);
    const reachScore = computeReachScore(areaSignals);
    const effort = estimateEffort(areaSignals, area);
    const riskScore = computeRiskScore(areaSignals);
    const priorityScore = computePriorityScore(impactScore, reachScore, effort, riskScore);
    const impactCategory = inferImpactCategory(areaSignals);
    const title = pickTitle(area, areaSignals);

    // Evidence summary: most-mentioned themes
    const topThemes = extractThemes(areaSignals).slice(0, 3);
    const uniqueUsers = new Set(areaSignals.filter(s => s.userId).map(s => s.userId)).size;
    const evidenceSummary = `${areaSignals.length} signals across ${new Set(areaSignals.map(s => s.sourceType)).size} sources. ${uniqueUsers > 0 ? `${uniqueUsers} unique users mentioned this.` : ''} Top themes: ${topThemes.join(', ')}.`;

    const candidate: FeatureCandidate = {
      id: generateId('feat'),
      title,
      description: `Feature area: ${area}. ${evidenceSummary}`,
      evidenceSummary,
      supportingSignals: areaSignals,
      productArea: area,
      impactCategory,
      impactScore,
      effortEstimate: effort,
      riskScore,
      priorityScore,
      createdAt: new Date(),
    };

    // Generate tickets for each candidate
    candidate.relatedTickets = generateTickets(candidate);

    candidates.push(candidate);
  }

  // 4. Rank candidates
  const ranked = rankCandidates(candidates).slice(0, query.maxCandidates ?? 5);

  return {
    query,
    candidates: ranked,
    signalCount: signals.length,
    themesSurfaced: extractThemes(signals),
    processingMs: Date.now() - t0,
    modelVersion: 'forge-v1.0.0',
    createdAt: new Date(),
  };
}

/**
 * Format an AnalysisResult as a human-readable markdown report.
 */
export function formatResultAsMarkdown(result: AnalysisResult): string {
  const lines: string[] = [
    `# Forge Analysis Report`,
    ``,
    `**Query:** ${result.query.question}`,
    `**Signals analyzed:** ${result.signalCount}`,
    `**Generated:** ${result.createdAt.toISOString()}`,
    `**Themes surfaced:** ${result.themesSurfaced.join(', ')}`,
    ``,
    `---`,
    ``,
    `## Top Recommendations`,
    ``,
  ];

  result.candidates.forEach((c, i) => {
    lines.push(`### ${i + 1}. ${c.title}`);
    lines.push(``);
    lines.push(`**Priority score:** ${c.priorityScore}/100 | **Impact:** ${c.impactScore}/100 | **Effort:** ${c.effortEstimate} | **Risk:** ${c.riskScore}/100`);
    lines.push(``);
    lines.push(`**Why build this?**`);
    lines.push(c.evidenceSummary);
    lines.push(``);

    if (c.supportingSignals.length > 0) {
      lines.push(`**Supporting user quotes:**`);
      c.supportingSignals.slice(0, 3).forEach(sig => {
        lines.push(`> "${sig.normalizedText}" — ${sig.sourceType}`);
      });
      lines.push(``);
    }

    if (c.relatedTickets && c.relatedTickets.length > 0) {
      lines.push(`**Dev tickets (${c.relatedTickets.length}):**`);
      c.relatedTickets.forEach(t => {
        lines.push(`- \`${t.id}\` [${t.labels.join(', ')}] ${t.title} (${t.estimatedHours ?? '?'}h)`);
      });
      lines.push(``);
    }

    lines.push(`---`);
    lines.push(``);
  });

  return lines.join('\n');
}
