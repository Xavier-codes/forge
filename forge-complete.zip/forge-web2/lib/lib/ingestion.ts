/**
 * Forge Signal Ingestion Pipeline
 *
 * Parses raw text from multiple source types into normalized Signal objects.
 * Each parser is a pure function: rawText → Signal[].
 */

import { Signal, SignalSource, IngestResult } from '../types';
import { generateId } from './utils';

// ─── Sentiment Classifier ────────────────────────────────────────────────────
// Lightweight keyword-based classifier. In production: fine-tuned model.

const PAIN_KEYWORDS = [
  'frustrating', 'annoying', 'broken', 'impossible', 'can\'t', 'cannot',
  'doesn\'t work', 'bug', 'error', 'stuck', 'lost', 'give up', 'almost quit',
  'hours', 'manually', 'pain', 'hard', 'difficult', 'confusing', 'unclear',
  'where is', 'i need', 'why can\'t', 'should be able', 'missing',
];

const REQUEST_KEYWORDS = [
  'would love', 'wish', 'please add', 'feature request', 'can you add',
  'when will', 'is there a way', 'integration', 'import', 'export',
  'notification', 'email', 'slack', 'webhook', 'api', 'automation',
];

const DELIGHT_KEYWORDS = [
  'love', 'amazing', 'great', 'perfect', 'best', 'fantastic', 'excellent',
  'fast', 'easy', 'intuitive', 'seamless', 'works well', 'appreciate',
];

const CHURN_KEYWORDS = [
  'cancel', 'switching', 'leaving', 'alternative', 'competitor', 'instead',
  'looking at', 'evaluate', 'trial', 'downgrade', 'too expensive',
];

export function classifySentiment(text: string): Signal['sentiment'] {
  const lower = text.toLowerCase();
  if (CHURN_KEYWORDS.some(k => lower.includes(k))) return 'churn_risk';
  const painCount = PAIN_KEYWORDS.filter(k => lower.includes(k)).length;
  const requestCount = REQUEST_KEYWORDS.filter(k => lower.includes(k)).length;
  const delightCount = DELIGHT_KEYWORDS.filter(k => lower.includes(k)).length;
  if (painCount >= 2 || painCount >= 1) return 'pain';
  if (requestCount >= 1) return 'request';
  if (delightCount >= 1) return 'delight';
  return 'neutral';
}

// ─── Theme Extractor ─────────────────────────────────────────────────────────

const THEME_PATTERNS: Record<string, RegExp> = {
  'onboarding': /onboard|setup|getting started|first time|sign.?up|day one/i,
  'bulk-import': /csv|import|bulk|batch|upload.*data|migrate|transfer/i,
  'notifications': /notif|alert|email digest|weekly|remind|ping/i,
  'slack-integration': /slack|teams|microsoft|discord|channel|workspace/i,
  'api-access': /\bapi\b|webhook|integration|connect|third.?party|zapier/i,
  'performance': /slow|fast|speed|lag|latency|load|performance/i,
  'mobile': /mobile|phone|ios|android|app/i,
  'reporting': /report|dashboard|analytic|chart|metric|insight|export/i,
  'search': /search|filter|find|lookup|query/i,
  'collaboration': /team|collaborat|share|permission|role|access/i,
};

export function extractThemesFromText(text: string): string[] {
  return Object.entries(THEME_PATTERNS)
    .filter(([, pattern]) => pattern.test(text))
    .map(([theme]) => theme);
}

// ─── Text Normalizer ─────────────────────────────────────────────────────────

export function normalizeText(raw: string): string {
  return raw
    .replace(/\s+/g, ' ')
    .replace(/\u201c|\u201d|\u201C|\u201D/g, '"')
    .replace(/\u2018|\u2019|\u2018|\u2019/g, "'")  // eslint-disable-line
    .trim();
}

// ─── Generic Signal Factory ───────────────────────────────────────────────────

export function makeSignal(
  rawText: string,
  sourceType: SignalSource,
  opts: Partial<Omit<Signal, 'id' | 'rawText' | 'normalizedText' | 'sourceType' | 'sentiment' | 'themes'>> = {}
): Signal {
  const normalized = normalizeText(rawText);
  const sentiment = classifySentiment(normalized);
  const themes = extractThemesFromText(normalized);

  return {
    id: generateId('sig'),
    rawText,
    normalizedText: normalized,
    sourceType,
    sentiment,
    themes,
    createdAt: opts.createdAt ?? new Date(),
    weight: opts.weight ?? 1.0,
    ...opts,
  };
}

// ─── Source Parsers ───────────────────────────────────────────────────────────

/**
 * Parse a plain-text interview transcript.
 * Splits on speaker turns, extracts user statements only.
 */
export function parseInterviewTranscript(
  transcript: string,
  opts: { userId?: string; userSegment?: string } = {}
): IngestResult {
  const t0 = Date.now();
  const errors: string[] = [];

  // Match lines that start with "User:", "Customer:", "P1:", etc.
  const userLinePattern = /^(?:user|customer|participant|interviewee|p\d+)\s*:\s*(.+)/gim;
  const signals: Signal[] = [];

  let match: RegExpExecArray | null;
  while ((match = userLinePattern.exec(transcript)) !== null) {
    const text = match[1].trim();
    if (text.length < 15) continue; // Skip very short utterances
    try {
      signals.push(makeSignal(text, 'interview', {
        userId: opts.userId,
        userSegment: opts.userSegment,
        weight: 1.0,
      }));
    } catch (e) {
      errors.push(`Parse error: ${String(e)}`);
    }
  }

  if (signals.length === 0) {
    errors.push('No user utterances found. Check transcript format.');
  }

  return {
    sourceType: 'interview',
    signalsExtracted: signals.length,
    signalsParsed: signals,
    errors,
    durationMs: Date.now() - t0,
  };
}

/**
 * Parse a CSV of feedback items.
 * Expected columns: text, user_id?, segment?, date?
 */
export function parseFeedbackCSV(
  csv: string,
  sourceType: SignalSource = 'intercom'
): IngestResult {
  const t0 = Date.now();
  const errors: string[] = [];
  const signals: Signal[] = [];

  const lines = csv.trim().split('\n');
  if (lines.length < 2) {
    return { sourceType, signalsExtracted: 0, signalsParsed: [], errors: ['CSV has no data rows'], durationMs: Date.now() - t0 };
  }

  const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
  const textIdx = headers.findIndex(h => ['text', 'body', 'message', 'feedback', 'comment'].includes(h));
  const userIdx = headers.findIndex(h => ['user_id', 'userid', 'customer_id'].includes(h));
  const segmentIdx = headers.findIndex(h => ['segment', 'plan', 'tier'].includes(h));
  const dateIdx = headers.findIndex(h => ['date', 'created_at', 'timestamp'].includes(h));

  if (textIdx === -1) {
    errors.push('Could not find text column. Expected: text, body, message, feedback, or comment.');
    return { sourceType, signalsExtracted: 0, signalsParsed: [], errors, durationMs: Date.now() - t0 };
  }

  for (let i = 1; i < lines.length; i++) {
    const cols = parseCSVLine(lines[i]);
    const rawText = cols[textIdx]?.replace(/^"|"$/g, '').trim();
    if (!rawText || rawText.length < 10) continue;

    try {
      const createdAt = dateIdx >= 0 && cols[dateIdx] ? new Date(cols[dateIdx]) : new Date();
      signals.push(makeSignal(rawText, sourceType, {
        userId: userIdx >= 0 ? cols[userIdx] : undefined,
        userSegment: segmentIdx >= 0 ? cols[segmentIdx] : undefined,
        createdAt: isNaN(createdAt.getTime()) ? new Date() : createdAt,
        weight: 0.8,
      }));
    } catch (e) {
      errors.push(`Row ${i}: ${String(e)}`);
    }
  }

  return {
    sourceType,
    signalsExtracted: signals.length,
    signalsParsed: signals,
    errors,
    durationMs: Date.now() - t0,
  };
}

/**
 * Parse a JSON array of signals from an API export (e.g. Intercom, Gong).
 */
export function parseJSONExport(
  json: string,
  sourceType: SignalSource
): IngestResult {
  const t0 = Date.now();
  const errors: string[] = [];
  const signals: Signal[] = [];

  let items: unknown[];
  try {
    items = JSON.parse(json);
    if (!Array.isArray(items)) items = [items];
  } catch (e) {
    return {
      sourceType,
      signalsExtracted: 0,
      signalsParsed: [],
      errors: [`Invalid JSON: ${String(e)}`],
      durationMs: Date.now() - t0,
    };
  }

  for (const item of items) {
    if (typeof item !== 'object' || item === null) continue;
    const obj = item as Record<string, unknown>;
    const rawText = String(obj.text ?? obj.body ?? obj.message ?? obj.content ?? '');
    if (rawText.length < 10) continue;
    try {
      signals.push(makeSignal(rawText, sourceType, {
        userId: typeof obj.user_id === 'string' ? obj.user_id : undefined,
        userSegment: typeof obj.segment === 'string' ? obj.segment : undefined,
        weight: 0.75,
      }));
    } catch (e) {
      errors.push(String(e));
    }
  }

  return {
    sourceType,
    signalsExtracted: signals.length,
    signalsParsed: signals,
    errors,
    durationMs: Date.now() - t0,
  };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Naive CSV line parser — handles basic quoting. */
function parseCSVLine(line: string): string[] {
  const cols: string[] = [];
  let cur = '';
  let inQuote = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') { inQuote = !inQuote; continue; }
    if (ch === ',' && !inQuote) { cols.push(cur); cur = ''; continue; }
    cur += ch;
  }
  cols.push(cur);
  return cols;
}
