/**
 * Forge Ticket Generator
 *
 * Takes a FeatureCandidate and generates a set of well-structured DevTickets
 * ready to paste into Linear, Jira, or feed directly to Cursor/Claude Code.
 */

import { FeatureCandidate, DevTicket, TicketLabel, TicketType, CodePointer } from '../types';
import { generateId } from './utils';

// ─── Ticket Templates by Feature Theme ───────────────────────────────────────

interface TicketTemplate {
  type: TicketType;
  title: string;
  descriptionTemplate: string;
  acceptanceCriteriaTemplate: string[];
  labels: TicketLabel[];
  effortMultiplier: number; // relative to base hours
  codePointers?: CodePointer[];
}

const THEME_TICKET_TEMPLATES: Record<string, TicketTemplate[]> = {
  'bulk-import': [
    {
      type: 'ui',
      title: 'Build CSV import flow — file picker + column mapping UI',
      descriptionTemplate: 'Create the user-facing import wizard for {feature}. Users upload a CSV, see a preview of the first 5 rows, and map their column names to our data model fields.',
      acceptanceCriteriaTemplate: [
        'File picker accepts .csv and .xlsx (max 10MB)',
        'Preview shows first 5 rows and detected column headers',
        'Column mapping dropdowns auto-suggest based on header similarity',
        'Validation errors shown inline per row (e.g. "Email invalid on row 4")',
        'Import progress indicator shows rows processed / total',
        'Success state shows count of records imported',
      ],
      labels: ['ui'],
      effortMultiplier: 1.5,
      codePointers: [
        { file: 'src/pages/ImportPage.tsx', description: 'New page', suggestedChange: 'Add multi-step wizard component' },
        { file: 'src/components/ColumnMapper.tsx', description: 'New component', suggestedChange: 'Drag-and-drop column matching UI' },
      ],
    },
    {
      type: 'backend',
      title: 'CSV parser API endpoint — validate + ingest records',
      descriptionTemplate: 'Implement POST /api/imports endpoint that accepts a multipart CSV upload, validates row data, and enqueues rows for background processing.',
      acceptanceCriteriaTemplate: [
        'Endpoint accepts multipart/form-data with "file" field',
        'Returns importJobId immediately (async processing)',
        'Validates each row against data model schema',
        'Returns per-row errors in validation response',
        'Rate limited to 3 concurrent imports per workspace',
        'Files deleted from storage after processing',
      ],
      labels: ['backend', 'api'],
      effortMultiplier: 1.2,
    },
    {
      type: 'data_model',
      title: 'DB migration — ImportJob and ImportRow tables',
      descriptionTemplate: 'Add database schema to track import jobs and individual row results. Enables the UI to poll for progress and display final error summary.',
      acceptanceCriteriaTemplate: [
        'ImportJob: id, workspace_id, status, total_rows, processed_rows, error_count, created_at, completed_at',
        'ImportRow: id, job_id, row_number, status, error_message, raw_data (jsonb)',
        'Indexed on: job_id, status',
        'Migration is reversible',
        'Unit test: can create, update, and query both tables',
      ],
      labels: ['data', 'backend'],
      effortMultiplier: 0.6,
    },
  ],

  'notifications': [
    {
      type: 'ui',
      title: 'Weekly digest email template (MJML)',
      descriptionTemplate: 'Design and build the weekly digest email for {feature}. Should show key metrics from the past week, top 3 items to act on, and a CTA back to the app.',
      acceptanceCriteriaTemplate: [
        'Renders correctly in Gmail, Outlook, Apple Mail',
        'Mobile-responsive (single column on <600px)',
        'Shows: workspace name, week date range, top 3 action items, metric deltas',
        'Unsubscribe link in footer (CAN-SPAM compliant)',
        'Preview mode in app settings',
        'Tested with @react-email or MJML',
      ],
      labels: ['ui'],
      effortMultiplier: 1.0,
    },
    {
      type: 'backend',
      title: 'Digest scheduler — cron job + user preferences',
      descriptionTemplate: 'Implement the backend for weekly email digests: a cron job that runs every Monday at 8am per user timezone, reads their preferences, and enqueues emails.',
      acceptanceCriteriaTemplate: [
        'Cron runs at 8am in user\'s local timezone (not UTC)',
        'Respects user opt-out preference',
        'Digest content generated per workspace (not per user — one per ws)',
        'Delivery tracked: sent, opened, clicked',
        'Retry on failure (up to 3x)',
        'Admin can trigger manual digest for testing',
      ],
      labels: ['backend', 'infra'],
      effortMultiplier: 1.3,
    },
  ],

  'slack-integration': [
    {
      type: 'feature',
      title: 'Slack OAuth flow — connect workspace',
      descriptionTemplate: 'Implement Slack OAuth 2.0 so users can connect their Slack workspace to {feature}. After auth, store bot token and default channel.',
      acceptanceCriteriaTemplate: [
        '"Connect Slack" button in Settings > Integrations',
        'OAuth redirect handled at /auth/slack/callback',
        'Bot token stored encrypted (not logged)',
        'Default notification channel selectable from dropdown (fetched via Slack API)',
        'Disconnect option revokes token via Slack API',
        'Error state if workspace already connected',
      ],
      labels: ['backend', 'ui'],
      effortMultiplier: 1.0,
    },
    {
      type: 'backend',
      title: 'Slack notification webhook routing',
      descriptionTemplate: 'Send configured event types to Slack as formatted Block Kit messages. Events: new insight surfaced, weekly digest summary, threshold alert.',
      acceptanceCriteriaTemplate: [
        'Block Kit message with title, description, and CTA button',
        'Per-event type toggle in user settings',
        'Retry logic on HTTP 5xx from Slack',
        'Message deduplication (same event not sent twice within 1hr)',
        'Admin test-send button',
      ],
      labels: ['backend', 'api'],
      effortMultiplier: 0.8,
    },
  ],
};

// ─── Effort Mapping ───────────────────────────────────────────────────────────

const BASE_HOURS: Record<FeatureCandidate['effortEstimate'], number> = {
  xs: 4,
  sm: 8,
  md: 20,
  lg: 40,
  xl: 80,
};

// ─── Main Generator ───────────────────────────────────────────────────────────

export function generateTickets(feature: FeatureCandidate): DevTicket[] {
  const tickets: DevTicket[] = [];
  const baseHours = BASE_HOURS[feature.effortEstimate];

  // Find matching templates by theme
  const matchedThemes = new Set<string>();
  for (const theme of feature.supportingSignals.flatMap(s => s.themes)) {
    if (THEME_TICKET_TEMPLATES[theme]) matchedThemes.add(theme);
  }

  // If no theme templates, generate a generic set
  if (matchedThemes.size === 0) {
    tickets.push(...generateGenericTickets(feature, baseHours));
    return tickets;
  }

  for (const theme of matchedThemes) {
    const templates = THEME_TICKET_TEMPLATES[theme];
    for (const tpl of templates) {
      const description = tpl.descriptionTemplate.replace(/{feature}/g, feature.title);
      const estimatedHours = Math.round(baseHours * tpl.effortMultiplier);

      tickets.push({
        id: generateId('FRG'),
        featureId: feature.id,
        type: tpl.type,
        title: tpl.title,
        description,
        acceptanceCriteria: tpl.acceptanceCriteriaTemplate,
        labels: tpl.labels,
        estimatedHours,
        status: 'todo',
        codePointers: tpl.codePointers,
        createdAt: new Date(),
      });
    }
  }

  // Always add a user research ticket if impact score is high but signal volume is low
  const signalVolumeIsLow = feature.supportingSignals.length < 5;
  const impactIsHigh = feature.impactScore >= 70;
  if (signalVolumeIsLow && impactIsHigh) {
    tickets.push(makeResearchTicket(feature));
  }

  return tickets;
}

function generateGenericTickets(feature: FeatureCandidate, baseHours: number): DevTicket[] {
  return [
    {
      id: generateId('FRG'),
      featureId: feature.id,
      type: 'research',
      title: `Discovery: define scope and success criteria for "${feature.title}"`,
      description: `Before building, validate the exact user need and agree on success metrics for: ${feature.title}\n\n${feature.evidenceSummary}`,
      acceptanceCriteria: [
        'User research interviews completed (min 3)',
        'Problem statement written and approved',
        'Success metrics defined (leading and lagging)',
        'Technical spike complete — no unknowns remain',
        'Scope written as user stories',
      ],
      labels: ['research'],
      estimatedHours: Math.round(baseHours * 0.3),
      status: 'todo',
      createdAt: new Date(),
    },
    {
      id: generateId('FRG'),
      featureId: feature.id,
      type: 'feature',
      title: `Implement: ${feature.title}`,
      description: `Build the ${feature.title} feature per scoped design. Evidence: ${feature.evidenceSummary}`,
      acceptanceCriteria: [
        'Feature works as designed',
        'Unit tests cover core logic (>80%)',
        'Integration tests cover happy path and error states',
        'Accessible (WCAG AA)',
        'Performance: P95 response < 500ms',
        'Feature flag enabled for 10% rollout before full launch',
      ],
      labels: ['ui', 'backend'],
      estimatedHours: baseHours,
      status: 'todo',
      createdAt: new Date(),
    },
  ];
}

function makeResearchTicket(feature: FeatureCandidate): DevTicket {
  return {
    id: generateId('FRG'),
    featureId: feature.id,
    type: 'research',
    title: `Validate: additional user research for "${feature.title}"`,
    description: `Impact score is high but signal volume is low (${feature.supportingSignals.length} signals). Run targeted interviews to confirm this is the right problem.`,
    acceptanceCriteria: [
      'Min 5 user interviews completed',
      'At least 3 from target segment',
      'Findings documented in Forge',
      'Go/no-go decision made by PM',
    ],
    labels: ['research'],
    estimatedHours: 8,
    status: 'todo',
    createdAt: new Date(),
  };
}
