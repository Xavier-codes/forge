/**
 * Forge Signal Scorer
 *
 * Converts raw signals into prioritized feature candidates.
 * Pure functions — no I/O, fully testable.
 */

import { Signal, FeatureCandidate, EffortEstimate, ImpactCategory } from '../types';

// ─── Effort → Numeric ────────────────────────────────────────────────────────

const EFFORT_POINTS: Record<EffortEstimate, number> = {
  xs: 1,
  sm: 2,
  md: 4,
  lg: 8,
  xl: 16,
};

// ─── Sentiment Weights ────────────────────────────────────────────────────────
// Pain and churn risk count more than general requests

const SENTIMENT_WEIGHT: Record<Signal['sentiment'], number> = {
  pain: 1.0,
  churn_risk: 1.4,   // Highest — user is at risk of leaving
  request: 0.7,
  neutral: 0.3,
  delight: 0.1,      // Delight is good but doesn't move feature priority
};

// ─── Source Weights ───────────────────────────────────────────────────────────
// Direct interview beats a G2 review for richness

const SOURCE_WEIGHT: Record<Signal['sourceType'], number> = {
  interview: 1.0,
  sales_call: 0.9,
  support: 0.75,
  nps: 0.65,
  intercom: 0.65,
  survey: 0.6,
  slack: 0.55,
  g2: 0.5,
  amplitude: 0.4,   // Quantitative data is supporting, not primary
  csv: 0.4,
};

// ─── Core Scoring Functions ──────────────────────────────────────────────────

/**
 * Compute a reach score for a set of signals.
 * Reach = how many unique users the feature will affect.
 */
export function computeReachScore(signals: Signal[]): number {
  const uniqueUsers = new Set(signals.filter(s => s.userId).map(s => s.userId!));
  const enterpriseBoost = signals.some(s => s.userSegment === 'enterprise') ? 1.3 : 1.0;
  return Math.min(100, uniqueUsers.size * 8 * enterpriseBoost + signals.length * 2);
}

/**
 * Compute an impact score from signals.
 * Factors: sentiment weight, source weight, user segment, recency.
 */
export function computeImpactScore(signals: Signal[]): number {
  if (signals.length === 0) return 0;

  const now = Date.now();
  const SIX_MONTHS_MS = 1000 * 60 * 60 * 24 * 180;

  const weightedSum = signals.reduce((acc, sig) => {
    const sentimentW = SENTIMENT_WEIGHT[sig.sentiment];
    const sourceW = SOURCE_WEIGHT[sig.sourceType];
    const ageDays = (now - sig.createdAt.getTime()) / (1000 * 60 * 60 * 24);
    const recencyW = Math.max(0.3, 1 - ageDays / 180); // Decays to 0.3 over 6 months
    const segmentW = sig.userSegment === 'enterprise' ? 1.5 : sig.userSegment === 'smb' ? 1.0 : 0.7;
    return acc + sentimentW * sourceW * recencyW * segmentW * sig.weight;
  }, 0);

  // Normalize to 0–100, with log scaling so large volumes don't dominate
  const normalized = Math.min(100, (weightedSum / signals.length) * 40 + Math.log(signals.length + 1) * 10);
  return Math.round(normalized);
}

/**
 * Compute a risk score.
 * Higher signals: few data points, all from same source, conflicting sentiments.
 */
export function computeRiskScore(signals: Signal[]): number {
  if (signals.length === 0) return 100;

  const sources = new Set(signals.map(s => s.sourceType));
  const sourceVariety = Math.min(1, sources.size / 3); // Good: 3+ sources
  const volumeConfidence = Math.min(1, signals.length / 8); // Good: 8+ signals
  const hasPain = signals.some(s => s.sentiment === 'pain');
  const hasRequest = signals.some(s => s.sentiment === 'request');
  const sentimentAlignment = hasPain && hasRequest ? 1.0 : 0.6;

  const confidence = (sourceVariety * 0.4 + volumeConfidence * 0.4 + sentimentAlignment * 0.2);
  return Math.round((1 - confidence) * 100);
}

/**
 * Compute the final priority score used for ranking.
 * Formula: (impact * reach) / effort * (1 - risk/100)
 * Similar to RICE but adapted for signal-driven data.
 */
export function computePriorityScore(
  impactScore: number,
  reachScore: number,
  effort: EffortEstimate,
  riskScore: number
): number {
  const effortPoints = EFFORT_POINTS[effort];
  const riskPenalty = 1 - riskScore / 100;
  const raw = (impactScore * 0.6 + reachScore * 0.4) / effortPoints * riskPenalty;
  return Math.round(Math.min(100, raw));
}

/**
 * Infer the most likely impact category from signal themes and text.
 */
export function inferImpactCategory(signals: Signal[]): ImpactCategory {
  const texts = signals.map(s => s.normalizedText.toLowerCase()).join(' ');
  const themes = signals.flatMap(s => s.themes).join(' ').toLowerCase();
  const combined = texts + ' ' + themes;

  if (/churn|cancel|leave|quit|switch|competitor|alternative/.test(combined)) return 'retention';
  if (/revenue|upgrade|pricing|plan|enterprise|deal|close|contract/.test(combined)) return 'revenue';
  if (/recommend|share|invite|viral|growth|referral|marketing/.test(combined)) return 'acquisition';
  if (/nps|satisfaction|love|great|best|rating|score/.test(combined)) return 'nps';
  return 'efficiency';
}

/**
 * Group signals by inferred theme and return top themes by signal count.
 */
export function extractThemes(signals: Signal[]): string[] {
  const themeCount: Record<string, number> = {};
  for (const sig of signals) {
    for (const theme of sig.themes) {
      themeCount[theme] = (themeCount[theme] ?? 0) + 1;
    }
  }
  return Object.entries(themeCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([theme]) => theme);
}

/**
 * Given a set of signals grouped by feature area, rank feature candidates.
 */
export function rankCandidates(candidates: FeatureCandidate[]): FeatureCandidate[] {
  return [...candidates].sort((a, b) => b.priorityScore - a.priorityScore);
}

/**
 * Deduplicate signals by normalized text similarity (simple substring check).
 * In production this would use embedding similarity.
 */
export function deduplicateSignals(signals: Signal[]): Signal[] {
  const seen = new Set<string>();
  return signals.filter(sig => {
    // Use first 60 chars as fingerprint
    const fp = sig.normalizedText.slice(0, 60).toLowerCase().replace(/\W+/g, '');
    if (seen.has(fp)) return false;
    seen.add(fp);
    return true;
  });
}
