/**
 * Forge — AI-native Product Management System
 *
 * Public API surface. Import from here in consuming code.
 *
 * @example
 * ```ts
 * import { Forge } from './index';
 *
 * const forge = new Forge();
 * const result = await forge.ingestCSV(csvString).analyze('What should I build next?');
 * console.log(forge.formatMarkdown(result));
 * ```
 */

export * from './types';
export * from './lib/scorer';
export * from './lib/ingestion';
export * from './lib/ticketGenerator';
export { analyze, formatResultAsMarkdown } from './lib/engine';

import { Signal, AnalysisResult } from './types';
import { parseFeedbackCSV, parseInterviewTranscript, parseJSONExport } from './lib/ingestion';
import { analyze, formatResultAsMarkdown } from './lib/engine';
import { deduplicateSignals } from './lib/scorer';

/**
 * Forge builder class — fluent API for ingesting data and running analysis.
 */
export class Forge {
  private signals: Signal[] = [];
  private workspaceId = 'default';

  constructor(workspaceId?: string) {
    if (workspaceId) this.workspaceId = workspaceId;
  }

  /** Load a feedback CSV string and add signals */
  ingestCSV(csv: string, sourceType: Signal['sourceType'] = 'intercom'): this {
    const result = parseFeedbackCSV(csv, sourceType);
    this.signals.push(...result.signalsParsed);
    if (result.errors.length > 0) {
      console.warn(`[Forge] Ingestion warnings (${sourceType}):`, result.errors);
    }
    return this;
  }

  /** Load an interview transcript and add signals */
  ingestInterview(transcript: string, opts?: { userId?: string; userSegment?: string }): this {
    const result = parseInterviewTranscript(transcript, opts);
    this.signals.push(...result.signalsParsed);
    return this;
  }

  /** Load a JSON export and add signals */
  ingestJSON(json: string, sourceType: Signal['sourceType']): this {
    const result = parseJSONExport(json, sourceType);
    this.signals.push(...result.signalsParsed);
    return this;
  }

  /** Add pre-built signals directly */
  addSignals(signals: Signal[]): this {
    this.signals.push(...signals);
    return this;
  }

  /** Get the current deduplicated signal count */
  get signalCount(): number {
    return deduplicateSignals(this.signals).length;
  }

  /** Run analysis and return a result */
  analyze(question: string, maxCandidates = 5): AnalysisResult {
    return analyze(
      { question, workspaceId: this.workspaceId, maxCandidates },
      this.signals
    );
  }

  /** Format a result as markdown */
  formatMarkdown(result: AnalysisResult): string {
    return formatResultAsMarkdown(result);
  }

  /** Reset signals (useful for testing) */
  reset(): this {
    this.signals = [];
    return this;
  }
}
