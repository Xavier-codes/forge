import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Forge — AI Product Discovery',
  description: 'Upload interviews and feedback. Ask what to build. Get ranked features with dev tickets ready for Cursor.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@400;500&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body style={{ background: 'var(--bg)', color: 'var(--text)', fontFamily: "'Instrument Sans', system-ui, sans-serif" }}>
        {children}
      </body>
    </html>
  )
}
