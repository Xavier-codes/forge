'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

const S = {
  serif: { fontFamily: "'DM Serif Display', serif" } as React.CSSProperties,
  mono: { fontFamily: "'DM Mono', monospace" } as React.CSSProperties,
}

function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <div style={{ width: size, height: size, background: '#E8824A', borderRadius: Math.round(size * 0.22), display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <svg width={size * 0.52} height={size * 0.52} viewBox="0 0 12 12" fill="none">
        <path d="M2 9L6 3L10 9" stroke="#1A0E06" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M4 7H8" stroke="#1A0E06" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
    </div>
  )
}

const STEPS = [
  { n: '01', title: 'Drop in your data', body: 'Interview transcripts, Intercom exports, G2 reviews, Amplitude CSVs. Forge ingests everything and normalises it into a unified signal store.' },
  { n: '02', title: 'Ask in plain language', body: 'Type any product question — "What should I build next quarter?" or "Why are users churning in week 1?" No dashboards, no tagging, no BI queries.' },
  { n: '03', title: 'Get ranked features', body: 'Forge clusters signals by product area, scores on impact × reach ÷ effort × risk, and surfaces ranked candidates with supporting user quotes.' },
  { n: '04', title: 'Ship dev tickets', body: 'Each recommendation ships with ready-made tickets — title, description, acceptance criteria, and code pointers — formatted for Linear, Jira, or Cursor.' },
]

const TESTIMONIALS = [
  { quote: "We cut our sprint planning from 3 hours to 20 minutes. Forge does in seconds what used to take two days of Notion archaeology.", name: 'Sarah Chen', title: 'Head of Product, Runway' },
  { quote: "I loaded 6 months of Intercom tickets and two sales call transcripts. In 30 seconds I had a prioritised roadmap I actually believed in.", name: 'Marcus Webb', title: 'Founder, Kabel' },
  { quote: "The dev tickets are shockingly good. I paste them directly into Cursor. It knows what to build, where to build it, and why.", name: 'Priya Nair', title: 'CTO, Stackwise' },
]

const PRICING = [
  {
    name: 'Seed', price: '$0', desc: 'For founders figuring out what to build.',
    features: ['500 signals/month', '3 analyses/week', 'CSV + transcript ingestion', 'Basic scoring engine'],
    cta: 'Start free', primary: false,
  },
  {
    name: 'Growth', price: '$149', desc: 'For PM teams shipping weekly.',
    features: ['50k signals/month', 'Unlimited analyses', 'All integrations (Intercom, Gong, Amplitude)', 'Claude PM verdicts + risk flags', 'Ticket export to Linear/Jira', 'Slack digest'],
    cta: 'Start 14-day trial', primary: true,
  },
  {
    name: 'Enterprise', price: 'Custom', desc: 'For companies with data and compliance requirements.',
    features: ['Unlimited signals', 'SSO/SAML', 'On-prem or VPC deployment', 'Custom integrations', 'Dedicated PM success manager', 'SLA'],
    cta: 'Talk to us', primary: false,
  },
]

export default function LandingPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleCTA = () => router.push('/')

  return (
    <div style={{ background: '#0A0A0B', color: '#F2F0EB', minHeight: '100vh', overflowX: 'hidden' }}>

      {/* ── NAV ─────────────────────────────────────────────────────── */}
      <nav style={{ position: 'sticky', top: 0, zIndex: 50, borderBottom: '0.5px solid rgba(255,255,255,0.07)', background: 'rgba(10,10,11,0.85)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 40px', height: 56 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <LogoMark size={26} />
          <span style={{ ...S.serif, fontSize: 20 }}>Forge</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          {['Product', 'Pricing', 'Docs'].map(item => (
            <span key={item} style={{ fontSize: 13, color: '#7A7875', cursor: 'pointer' }}>{item}</span>
          ))}
          <button onClick={handleCTA} style={{ padding: '7px 18px', borderRadius: 8, background: '#E8824A', color: '#1A0E06', border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
            Open app →
          </button>
        </div>
      </nav>

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section style={{ maxWidth: 960, margin: '0 auto', padding: '100px 40px 80px', textAlign: 'center' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '5px 14px', borderRadius: 20, border: '0.5px solid rgba(232,130,74,0.3)', background: 'rgba(232,130,74,0.1)', marginBottom: 32 }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#E8824A' }} />
          <span style={{ fontSize: 12, color: '#E8824A', ...S.mono }}>YC S26 · now in alpha</span>
        </div>

        <h1 style={{ ...S.serif, fontSize: 'clamp(42px, 7vw, 76px)', lineHeight: 1.08, letterSpacing: '-0.02em', marginBottom: 24 }}>
          Cursor for<br />
          <em style={{ color: '#E8824A' }}>product managers</em>
        </h1>

        <p style={{ fontSize: 18, color: '#7A7875', lineHeight: 1.7, maxWidth: 560, margin: '0 auto 40px' }}>
          Upload your customer interviews and feedback. Ask what to build. Get ranked features backed by your users' own words — with dev tickets ready for Cursor.
        </p>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' as const }}>
          <button onClick={handleCTA} style={{ padding: '14px 32px', borderRadius: 10, background: '#E8824A', color: '#1A0E06', border: 'none', cursor: 'pointer', fontSize: 15, fontWeight: 600 }}>
            Try it free — no account needed
          </button>
          <button style={{ padding: '14px 28px', borderRadius: 10, background: 'transparent', color: '#F2F0EB', border: '0.5px solid rgba(255,255,255,0.15)', cursor: 'pointer', fontSize: 15 }}>
            Watch 2-min demo
          </button>
        </div>

        <p style={{ fontSize: 12, color: '#7A7875', marginTop: 16, ...S.mono }}>
          No credit card · Works with your existing Intercom, Gong, and Amplitude data
        </p>
      </section>

      {/* ── PRODUCT SCREENSHOT / DEMO ────────────────────────────────── */}
      <section style={{ maxWidth: 1100, margin: '0 auto', padding: '0 40px 100px' }}>
        <div style={{ border: '0.5px solid rgba(255,255,255,0.1)', borderRadius: 16, overflow: 'hidden', background: '#111113' }}>
          {/* Fake chrome bar */}
          <div style={{ padding: '12px 16px', borderBottom: '0.5px solid rgba(255,255,255,0.07)', display: 'flex', gap: 8, alignItems: 'center' }}>
            {['#D46B6B', '#E8824A', '#5DAA78'].map(c => <div key={c} style={{ width: 11, height: 11, borderRadius: '50%', background: c, opacity: 0.7 }} />)}
            <div style={{ flex: 1, textAlign: 'center', fontSize: 12, color: '#7A7875', ...S.mono }}>app.forgepm.io</div>
          </div>
          {/* Mock app UI */}
          <div style={{ display: 'flex', height: 420 }}>
            {/* Sidebar */}
            <div style={{ width: 180, borderRight: '0.5px solid rgba(255,255,255,0.07)', padding: '12px 8px', background: '#0E0E10' }}>
              {['Discovery', 'Signals', 'Dev Tickets'].map((item, i) => (
                <div key={item} style={{ padding: '7px 10px', borderRadius: 8, marginBottom: 2, background: i === 0 ? 'rgba(232,130,74,0.15)' : 'transparent', color: i === 0 ? '#E8824A' : '#7A7875', fontSize: 13 }}>{item}</div>
              ))}
            </div>
            {/* Main */}
            <div style={{ flex: 1, padding: 24, overflowY: 'auto' }}>
              <div style={{ ...S.serif, fontSize: 20, marginBottom: 16 }}>Product Discovery</div>
              {/* Candidates */}
              {[
                { rank: 1, title: 'Bulk CSV import for account setup', score: 84, signals: 6, effort: 'MD', color: '#E8824A' },
                { rank: 2, title: 'Weekly digest email', score: 71, signals: 11, effort: 'SM', color: '#6B9FD4' },
                { rank: 3, title: 'Slack & Teams integration', score: 58, signals: 9, effort: 'LG', color: '#5DAA78' },
              ].map(c => (
                <div key={c.rank} style={{ background: '#18181B', border: `0.5px solid rgba(255,255,255,0.07)`, borderLeft: `3px solid ${c.color}`, borderRadius: 10, padding: '12px 14px', marginBottom: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 20, height: 20, background: 'rgba(255,255,255,0.05)', borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, color: '#7A7875', ...S.mono }}>{c.rank}</div>
                    <div style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{c.title}</div>
                    <div style={{ fontSize: 11, ...S.mono, color: c.color }}>{c.score}/100</div>
                  </div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                    {[`${c.signals} signals`, `Effort: ${c.effort}`].map(t => (
                      <span key={t} style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, border: '0.5px solid rgba(255,255,255,0.1)', color: '#7A7875', ...S.mono }}>{t}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ─────────────────────────────────────────────── */}
      <section style={{ maxWidth: 960, margin: '0 auto', padding: '0 40px 100px' }}>
        <div style={{ textAlign: 'center', marginBottom: 60 }}>
          <div style={{ fontSize: 11, color: '#E8824A', ...S.mono, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 12 }}>How it works</div>
          <h2 style={{ ...S.serif, fontSize: 40, lineHeight: 1.15 }}>From raw feedback to shipped tickets<br />in under a minute</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 24 }}>
          {STEPS.map(step => (
            <div key={step.n} style={{ padding: 24, border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, background: '#111113' }}>
              <div style={{ fontSize: 12, color: '#E8824A', ...S.mono, marginBottom: 12 }}>{step.n}</div>
              <div style={{ fontSize: 16, fontWeight: 500, marginBottom: 10 }}>{step.title}</div>
              <div style={{ fontSize: 13, color: '#7A7875', lineHeight: 1.65 }}>{step.body}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── SCORING EXPLAINER ────────────────────────────────────────── */}
      <section style={{ maxWidth: 960, margin: '0 auto', padding: '0 40px 100px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 11, color: '#E8824A', ...S.mono, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 12 }}>The engine</div>
            <h2 style={{ ...S.serif, fontSize: 34, lineHeight: 1.2, marginBottom: 16 }}>Not vibes. Not votes.<br />A scoring model.</h2>
            <p style={{ fontSize: 14, color: '#7A7875', lineHeight: 1.7, marginBottom: 24 }}>
              Forge weights every signal by sentiment intensity, source credibility, recency, and user segment. A churn-risk quote from an enterprise customer on a sales call is worth 3× a G2 review from a free user. Pain beats requests. Recent beats old.
            </p>
            <div style={{ padding: '14px 18px', background: '#111113', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 10, ...S.mono }}>
              <div style={{ fontSize: 10, color: '#7A7875', marginBottom: 6 }}>priority formula</div>
              <div style={{ fontSize: 13, color: '#E8824A' }}>
                (impact × reach) ÷ effort × (1 − risk)
              </div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {[
              { label: 'Churn signal', weight: '1.4×', color: '#E8824A' },
              { label: 'Pain signal', weight: '1.0×', color: '#D46B6B' },
              { label: 'Enterprise tier', weight: '1.5×', color: '#9B7ED4' },
              { label: 'Interview source', weight: '1.0×', color: '#5DAA78' },
              { label: 'G2 review', weight: '0.5×', color: '#6B9FD4' },
              { label: '6-month decay', weight: '0.3×', color: '#7A7875' },
            ].map(item => (
              <div key={item.label} style={{ padding: '12px 14px', background: '#111113', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 8 }}>
                <div style={{ fontSize: 18, fontWeight: 600, color: item.color, marginBottom: 4 }}>{item.weight}</div>
                <div style={{ fontSize: 12, color: '#7A7875' }}>{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ─────────────────────────────────────────────── */}
      <section style={{ maxWidth: 960, margin: '0 auto', padding: '0 40px 100px' }}>
        <div style={{ textAlign: 'center', marginBottom: 50 }}>
          <div style={{ fontSize: 11, color: '#E8824A', ...S.mono, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 12 }}>Early feedback</div>
          <h2 style={{ ...S.serif, fontSize: 36 }}>What PMs say</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 20 }}>
          {TESTIMONIALS.map((t, i) => (
            <div key={i} style={{ padding: 24, border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, background: '#111113' }}>
              <p style={{ fontSize: 14, color: '#F2F0EB', lineHeight: 1.7, fontStyle: 'italic', marginBottom: 18 }}>"{t.quote}"</p>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{t.name}</div>
              <div style={{ fontSize: 12, color: '#7A7875' }}>{t.title}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── PRICING ──────────────────────────────────────────────────── */}
      <section style={{ maxWidth: 960, margin: '0 auto', padding: '0 40px 100px' }} id="pricing">
        <div style={{ textAlign: 'center', marginBottom: 50 }}>
          <div style={{ fontSize: 11, color: '#E8824A', ...S.mono, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 12 }}>Pricing</div>
          <h2 style={{ ...S.serif, fontSize: 36 }}>Simple. No seat fees.</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {PRICING.map(plan => (
            <div key={plan.name} style={{ padding: 28, border: plan.primary ? '1.5px solid rgba(232,130,74,0.5)' : '0.5px solid rgba(255,255,255,0.07)', borderRadius: 14, background: plan.primary ? 'rgba(232,130,74,0.05)' : '#111113', position: 'relative' as const }}>
              {plan.primary && (
                <div style={{ position: 'absolute', top: -1, left: '50%', transform: 'translateX(-50%)', background: '#E8824A', color: '#1A0E06', fontSize: 10, padding: '3px 12px', borderRadius: '0 0 8px 8px', fontWeight: 600, ...S.mono }}>MOST POPULAR</div>
              )}
              <div style={{ fontSize: 13, color: '#E8824A', ...S.mono, marginBottom: 8 }}>{plan.name}</div>
              <div style={{ ...S.serif, fontSize: 36, marginBottom: 4 }}>{plan.price}</div>
              <div style={{ fontSize: 12, color: '#7A7875', marginBottom: 20 }}>{plan.price !== 'Custom' ? '/month' : ''} {plan.desc}</div>
              <div style={{ borderTop: '0.5px solid rgba(255,255,255,0.07)', paddingTop: 20, marginBottom: 24 }}>
                {plan.features.map(f => (
                  <div key={f} style={{ display: 'flex', gap: 8, marginBottom: 10, fontSize: 13, color: '#F2F0EB' }}>
                    <span style={{ color: '#5DAA78', marginTop: 1 }}>✓</span>
                    {f}
                  </div>
                ))}
              </div>
              <button onClick={handleCTA} style={{ width: '100%', padding: '12px', borderRadius: 9, background: plan.primary ? '#E8824A' : 'transparent', color: plan.primary ? '#1A0E06' : '#F2F0EB', border: plan.primary ? 'none' : '0.5px solid rgba(255,255,255,0.15)', cursor: 'pointer', fontSize: 14, fontWeight: plan.primary ? 600 : 400 }}>
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* ── FINAL CTA ────────────────────────────────────────────────── */}
      <section style={{ maxWidth: 700, margin: '0 auto', padding: '0 40px 120px', textAlign: 'center' }}>
        <h2 style={{ ...S.serif, fontSize: 48, lineHeight: 1.1, marginBottom: 20 }}>
          Your users already know<br />
          <em style={{ color: '#E8824A' }}>what you should build.</em>
        </h2>
        <p style={{ fontSize: 16, color: '#7A7875', marginBottom: 36, lineHeight: 1.6 }}>
          They've written it in support tickets, said it in sales calls, left it in G2 reviews. Forge finds it, scores it, and hands it to you — ranked, evidenced, and ready to ship.
        </p>

        {!submitted ? (
          <div style={{ display: 'flex', gap: 0, maxWidth: 440, margin: '0 auto', borderRadius: 10, overflow: 'hidden', border: '0.5px solid rgba(255,255,255,0.15)' }}>
            <input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') setSubmitted(true) }}
              style={{ flex: 1, background: '#111113', border: 'none', outline: 'none', padding: '14px 18px', fontSize: 14, color: '#F2F0EB' }}
            />
            <button
              onClick={() => setSubmitted(true)}
              style={{ padding: '14px 24px', background: '#E8824A', color: '#1A0E06', border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap' as const }}
            >
              Get early access
            </button>
          </div>
        ) : (
          <div style={{ maxWidth: 440, margin: '0 auto', padding: '16px 24px', background: 'rgba(93,170,120,0.1)', border: '0.5px solid rgba(93,170,120,0.3)', borderRadius: 10, fontSize: 14, color: '#5DAA78' }}>
            ✓ You're on the list. We'll reach out within 48 hours.
          </div>
        )}

        <div style={{ marginTop: 40, display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' as const }}>
          <button onClick={handleCTA} style={{ padding: '10px 22px', borderRadius: 8, background: 'transparent', color: '#7A7875', border: '0.5px solid rgba(255,255,255,0.1)', cursor: 'pointer', fontSize: 13 }}>
            Or just open the app — no signup →
          </button>
        </div>
      </section>

      {/* ── FOOTER ───────────────────────────────────────────────────── */}
      <footer style={{ borderTop: '0.5px solid rgba(255,255,255,0.07)', padding: '32px 40px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <LogoMark size={20} />
          <span style={{ ...S.serif, fontSize: 16 }}>Forge</span>
          <span style={{ fontSize: 12, color: '#7A7875', marginLeft: 8 }}>© 2026 Forge Technologies Inc.</span>
        </div>
        <div style={{ display: 'flex', gap: 24 }}>
          {['Privacy', 'Terms', 'Security', 'Status'].map(item => (
            <span key={item} style={{ fontSize: 12, color: '#7A7875', cursor: 'pointer' }}>{item}</span>
          ))}
        </div>
      </footer>
    </div>
  )
}
