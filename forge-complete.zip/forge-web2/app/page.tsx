'use client'

import { useState, useRef, useCallback, useEffect } from 'react'
import { Zap, BarChart2, Ticket, ChevronRight, AlertTriangle, CheckCircle2, Upload, Download, FileText, Database, ExternalLink } from 'lucide-react'

// ─── Types ───────────────────────────────────────────────────────────────────

interface Signal {
  id: string; sourceType: string; normalizedText: string; sentiment: string
  themes: string[]; userId?: string; userSegment?: string; createdAt: string; weight: number
}
interface DevTicket {
  id: string; type: string; title: string; description: string
  acceptanceCriteria: string[]; labels: string[]; estimatedHours?: number; status: string
}
interface Candidate {
  id: string; title: string; evidenceSummary: string; supportingSignals: Signal[]
  productArea: string; impactCategory: string; impactScore: number
  effortEstimate: string; riskScore: number; priorityScore: number
  relatedTickets?: DevTicket[]; pmVerdict?: string; watchOut?: string
}
interface AnalysisResult {
  candidates: Candidate[]; signalCount: number; themesSurfaced: string[]; processingMs: number
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const SENTIMENT_COLOR: Record<string, string> = {
  pain: '#D46B6B', churn_risk: '#E8824A', request: '#6B9FD4', delight: '#5DAA78', neutral: '#7A7875'
}
const pill = (color: string, bg: string, border: string): React.CSSProperties => ({
  fontSize: 10, fontFamily: "'DM Mono', monospace", padding: '3px 8px', borderRadius: 4,
  background: bg, color, border: `0.5px solid ${border}`, display: 'inline-block'
})
const LABEL_PILLS: Record<string, React.CSSProperties> = {
  ui: pill('#9B7ED4', 'rgba(155,126,212,0.12)', 'rgba(155,126,212,0.25)'),
  backend: pill('#6B9FD4', 'rgba(107,159,212,0.12)', 'rgba(107,159,212,0.25)'),
  data: pill('#5DAA78', 'rgba(93,170,120,0.12)', 'rgba(93,170,120,0.25)'),
  research: pill('#E8824A', 'rgba(232,130,74,0.15)', 'rgba(232,130,74,0.3)'),
  infra: pill('#7A7875', 'rgba(122,120,117,0.1)', 'rgba(122,120,117,0.2)'),
  api: pill('#6B9FD4', 'rgba(107,159,212,0.12)', 'rgba(107,159,212,0.25)'),
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function Logo() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ width: 22, height: 22, background: '#E8824A', borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path d="M2 9L6 3L10 9" stroke="#1A0E06" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4 7H8" stroke="#1A0E06" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      </div>
      <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: 19 }}>Forge</span>
    </div>
  )
}

function ScoreBar({ score, color }: { score: number; color: string }) {
  return (
    <div style={{ height: 3, background: 'rgba(255,255,255,0.07)', borderRadius: 2, overflow: 'hidden', width: '100%' }}>
      <div style={{ height: '100%', width: `${Math.min(100, score)}%`, background: color, borderRadius: 2, transition: 'width 0.8s ease' }} />
    </div>
  )
}

function TicketCard({ ticket }: { ticket: DevTicket }) {
  const [open, setOpen] = useState(false)
  return (
    <div style={{ background: '#111113', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 10, padding: '12px 14px', marginBottom: 8, cursor: 'pointer' }} onClick={() => setOpen(o => !o)}>
      <div style={{ fontSize: 10, fontFamily: "'DM Mono', monospace", color: '#7A7875', marginBottom: 4 }}>{ticket.id}</div>
      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8, lineHeight: 1.4 }}>{ticket.title}</div>
      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' as const }}>
        {ticket.labels.map(l => <span key={l} style={LABEL_PILLS[l] ?? LABEL_PILLS.infra}>{l}</span>)}
        {ticket.estimatedHours && <span style={pill('#7A7875', 'rgba(122,120,117,0.08)', 'rgba(255,255,255,0.07)')}>{ticket.estimatedHours}h</span>}
      </div>
      {open && ticket.acceptanceCriteria.length > 0 && (
        <div style={{ borderTop: '0.5px solid rgba(255,255,255,0.07)', paddingTop: 10, marginTop: 10 }}>
          {ticket.acceptanceCriteria.map((ac, i) => (
            <div key={i} style={{ display: 'flex', gap: 6, alignItems: 'flex-start', marginBottom: 5 }}>
              <CheckCircle2 size={11} color="#5DAA78" style={{ flexShrink: 0, marginTop: 2 }} />
              <span style={{ fontSize: 11, color: '#7A7875', lineHeight: 1.5 }}>{ac}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function CandidateCard({ candidate, index, isExpanded, onToggle }: {
  candidate: Candidate; index: number; isExpanded: boolean; onToggle: () => void
}) {
  const borderAccent = index === 0 ? '#E8824A' : index === 1 ? '#6B9FD4' : 'rgba(255,255,255,0.07)'
  const effortPct = ({ xs: 12, sm: 28, md: 55, lg: 75, xl: 95 }[candidate.effortEstimate] ?? 50)

  return (
    <div style={{ background: '#18181B', border: `0.5px solid rgba(255,255,255,0.09)`, borderLeft: `3px solid ${borderAccent}`, borderRadius: 12, marginBottom: 10, animation: `fadeIn 0.35s ease ${index * 0.08}s both` }}>
      <div style={{ padding: '16px 16px 0', cursor: 'pointer' }} onClick={onToggle}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#7A7875', background: 'rgba(255,255,255,0.05)', width: 24, height: 24, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>{index + 1}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 5 }}>{candidate.title}</div>
            <div style={{ fontSize: 12, color: '#7A7875', lineHeight: 1.5 }}>{candidate.evidenceSummary}</div>
          </div>
          <ChevronRight size={14} color="#7A7875" style={{ transform: isExpanded ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s', flexShrink: 0, marginTop: 4 }} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, margin: '14px 0 0 36px' }}>
          {[
            { label: 'Impact', score: candidate.impactScore, display: `${candidate.impactScore}`, color: '#E8824A' },
            { label: 'Effort', score: effortPct, display: candidate.effortEstimate.toUpperCase(), color: '#6B9FD4' },
            { label: 'Risk', score: candidate.riskScore, display: `${candidate.riskScore}`, color: '#D46B6B' },
          ].map(({ label, score, display, color }) => (
            <div key={label}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                <span style={{ fontSize: 10, color: '#7A7875', fontFamily: "'DM Mono', monospace", textTransform: 'uppercase' as const }}>{label}</span>
                <span style={{ fontSize: 10, color, fontFamily: "'DM Mono', monospace" }}>{display}</span>
              </div>
              <ScoreBar score={score} color={color} />
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' as const, margin: '12px 0 14px 36px', paddingBottom: 14, borderBottom: isExpanded ? '0.5px solid rgba(255,255,255,0.07)' : 'none' }}>
          <span style={pill('#E8824A', 'rgba(232,130,74,0.15)', 'rgba(232,130,74,0.3)')}>{candidate.priorityScore}/100 priority</span>
          <span style={pill('#6B9FD4', 'rgba(107,159,212,0.12)', 'rgba(107,159,212,0.25)')}>{candidate.supportingSignals.length} signals</span>
          <span style={pill('#5DAA78', 'rgba(93,170,120,0.12)', 'rgba(93,170,120,0.25)')}>{candidate.impactCategory}</span>
          {candidate.relatedTickets && <span style={pill('#7A7875', 'rgba(122,120,117,0.08)', 'rgba(255,255,255,0.07)')}>{candidate.relatedTickets.length} tickets</span>}
        </div>
      </div>

      {isExpanded && (
        <div style={{ padding: '0 16px 16px' }}>
          {candidate.pmVerdict && (
            <div style={{ background: 'rgba(232,130,74,0.08)', border: '0.5px solid rgba(232,130,74,0.3)', borderRadius: 8, padding: '10px 14px', marginBottom: 12 }}>
              <div style={{ fontSize: 10, color: '#E8824A', fontFamily: "'DM Mono', monospace", textTransform: 'uppercase' as const, marginBottom: 5 }}>PM Verdict · Claude</div>
              <div style={{ fontSize: 13, color: '#F2F0EB', lineHeight: 1.65 }}>{candidate.pmVerdict}</div>
            </div>
          )}
          {candidate.watchOut && (
            <div style={{ display: 'flex', gap: 8, background: 'rgba(212,107,107,0.1)', border: '0.5px solid rgba(212,107,107,0.25)', borderRadius: 8, padding: '10px 14px', marginBottom: 12 }}>
              <AlertTriangle size={13} color="#D46B6B" style={{ flexShrink: 0, marginTop: 2 }} />
              <div>
                <div style={{ fontSize: 10, color: '#D46B6B', fontFamily: "'DM Mono', monospace", textTransform: 'uppercase' as const, marginBottom: 4 }}>Watch out</div>
                <div style={{ fontSize: 12, color: '#7A7875', lineHeight: 1.5 }}>{candidate.watchOut}</div>
              </div>
            </div>
          )}
          {candidate.supportingSignals.filter(s => ['pain', 'churn_risk', 'request'].includes(s.sentiment)).slice(0, 4).map((sig, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              <div style={{ width: 2, background: SENTIMENT_COLOR[sig.sentiment] ?? '#7A7875', borderRadius: 1, flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: 12, color: '#F2F0EB', fontStyle: 'italic', lineHeight: 1.55 }}>"{sig.normalizedText}"</div>
                <div style={{ fontSize: 10, color: '#7A7875', fontFamily: "'DM Mono', monospace", marginTop: 3 }}>{sig.sourceType} · {sig.sentiment}</div>
              </div>
            </div>
          ))}
          {candidate.relatedTickets && candidate.relatedTickets.length > 0 && (
            <div style={{ marginTop: 14 }}>
              <div style={{ fontSize: 10, color: '#7A7875', fontFamily: "'DM Mono', monospace", textTransform: 'uppercase' as const, marginBottom: 8 }}>Dev tickets — paste into Linear / Cursor</div>
              {candidate.relatedTickets.map(t => <TicketCard key={t.id} ticket={t} />)}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────

type View = 'discovery' | 'signals' | 'tickets'

const SAMPLE_INTERVIEW = `Interviewer: Tell me about your first week.
User: We have about 400 contacts from our old CRM and doing it manually was impossible. I almost gave up.
Interviewer: What would help?
User: A CSV import. Like Airtable has. That would fix everything.
Interviewer: Anything else?
User: The product is great but I keep forgetting to check it. A weekly digest email would really help.`

const SAMPLE_CSV = `text,user_id,segment
"CSV import is the number one thing holding us back",u-001,enterprise
"I can't figure out where to import my contacts",u-002,smb
"Please add Slack notifications — we live in Slack",u-003,enterprise
"When will Slack integration be available?",u-004,smb
"I almost cancelled because onboarding was so painful without import",u-005,enterprise
"A weekly email summary would help me remember to check the product",u-006,smb
"Switching to a competitor if Slack isn't added soon",u-008,enterprise
"CSV bulk import would save our team hours every week",u-009,enterprise`

export default function ForgePage() {
  const [view, setView] = useState<View>('discovery')
  const [question, setQuestion] = useState('')
  const [signals, setSignals] = useState<Signal[]>([])
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [candidates, setCandidates] = useState<Candidate[]>([])
  const [streaming, setStreaming] = useState(false)
  const [statusMsg, setStatusMsg] = useState('')
  const [expandedCards, setExpandedCards] = useState<Set<number>>(new Set([0]))
  const [dataLoaded, setDataLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const dropRef = useRef<HTMLDivElement>(null)

  // File upload handler
  const handleFile = useCallback(async (file: File) => {
    setUploading(true)
    setError(null)
    try {
      const text = await file.text()
      const isCSV = file.name.endsWith('.csv') || file.type === 'text/csv'
      const type = isCSV ? 'csv' : 'interview'
      const sourceType = isCSV ? 'intercom' : 'interview'

      const res = await fetch('/api/ingest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, content: text, sourceType }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setSignals(prev => {
        const existing = new Set(prev.map(s => s.id))
        const fresh = (data.signals ?? []).filter((s: Signal) => !existing.has(s.id))
        return [...prev, ...fresh]
      })
      setDataLoaded(true)
      setStatusMsg(`+${data.signalsExtracted} signals from ${file.name}`)
    } catch (e) {
      setError(String(e))
    } finally {
      setUploading(false)
    }
  }, [])

  const loadSampleData = useCallback(async () => {
    setUploading(true)
    setError(null)
    try {
      const [r1, r2] = await Promise.all([
        fetch('/api/ingest', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'interview', content: SAMPLE_INTERVIEW, userId: 'cust-001', userSegment: 'enterprise' }) }),
        fetch('/api/ingest', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'csv', content: SAMPLE_CSV, sourceType: 'intercom' }) }),
      ])
      const [d1, d2] = await Promise.all([r1.json(), r2.json()])
      const merged = [...(d1.signals ?? []), ...(d2.signals ?? [])]
      setSignals(merged)
      setDataLoaded(true)
      setStatusMsg(`${merged.length} signals loaded from sample dataset`)
    } catch (e) {
      setError(String(e))
    } finally {
      setUploading(false)
    }
  }, [])

  // Streaming analysis
  const runAnalysis = useCallback(async () => {
    if (!question.trim()) return
    setError(null)
    setResult(null)
    setCandidates([])
    setExpandedCards(new Set([0]))
    setStreaming(true)
    setStatusMsg('Connecting…')

    try {
      const res = await fetch('/api/analyze-stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, signals }),
      })

      if (!res.ok || !res.body) throw new Error('Stream failed')

      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      // Per-candidate token accumulation for live rendering
      const tokenBuffers: Record<string, { pmVerdict: string; watchOut: string }> = {}

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const parts = buffer.split('\n\n')
        buffer = parts.pop() ?? ''

        for (const part of parts) {
          const line = part.replace(/^data: /, '').trim()
          if (!line) continue
          try {
            const msg = JSON.parse(line)

            if (msg.type === 'status') {
              setStatusMsg(msg.message)
            } else if (msg.type === 'engine') {
              // Engine result arrived — render candidates immediately
              const engineCandidates: Candidate[] = msg.payload.candidates
              setCandidates(engineCandidates)
              setResult({ candidates: engineCandidates, signalCount: msg.payload.signalCount, themesSurfaced: msg.payload.themesSurfaced, processingMs: msg.payload.processingMs })
              setStatusMsg(`${engineCandidates.length} features scored — enriching with Claude…`)
              engineCandidates.forEach(c => { tokenBuffers[c.id] = { pmVerdict: '', watchOut: '' } })
            } else if (msg.type === 'token') {
              // Streaming tokens — update candidate live
              if (tokenBuffers[msg.candidateId]) {
                if (msg.field === 'pmVerdict') tokenBuffers[msg.candidateId].pmVerdict += msg.token
                else if (msg.field === 'watchOut') tokenBuffers[msg.candidateId].watchOut += msg.token
                // Update candidates state with partial text
                setCandidates(prev => prev.map(c =>
                  c.id === msg.candidateId
                    ? { ...c, pmVerdict: tokenBuffers[msg.candidateId].pmVerdict, watchOut: tokenBuffers[msg.candidateId].watchOut }
                    : c
                ))
              }
            } else if (msg.type === 'enrich') {
              // Finalized enrichment for one candidate
              setCandidates(prev => prev.map(c =>
                c.id === msg.candidateId ? { ...c, pmVerdict: msg.pmVerdict, watchOut: msg.watchOut } : c
              ))
            } else if (msg.type === 'done') {
              setStatusMsg('Analysis complete')
              setStreaming(false)
            } else if (msg.type === 'error') {
              throw new Error(msg.message)
            }
          } catch {
            // Skip malformed SSE events
          }
        }
      }
    } catch (e) {
      setError(String(e))
      setStreaming(false)
    }
  }, [question, signals])

  // Export handler
  const exportResult = useCallback(async (format: 'markdown' | 'json' | 'csv') => {
    if (!result && candidates.length === 0) return
    const payload = result ? { ...result, candidates } : { candidates, signalCount: signals.length, themesSurfaced: [], processingMs: 0 }
    const res = await fetch('/api/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ format, result: payload, question }),
    })
    const blob = await res.blob()
    const ext = format === 'markdown' ? 'md' : format === 'json' ? 'json' : 'csv'
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `forge-analysis-${new Date().toISOString().slice(0, 10)}.${ext}`
    a.click()
    URL.revokeObjectURL(url)
  }, [result, candidates, signals, question])

  // Drag-and-drop
  useEffect(() => {
    const el = dropRef.current
    if (!el) return
    const over = (e: DragEvent) => { e.preventDefault(); el.style.borderColor = 'rgba(232,130,74,0.5)' }
    const leave = () => { el.style.borderColor = 'rgba(255,255,255,0.1)' }
    const drop = (e: DragEvent) => { e.preventDefault(); leave(); const f = e.dataTransfer?.files[0]; if (f) handleFile(f) }
    el.addEventListener('dragover', over)
    el.addEventListener('dragleave', leave)
    el.addEventListener('drop', drop)
    return () => { el.removeEventListener('dragover', over); el.removeEventListener('dragleave', leave); el.removeEventListener('drop', drop) }
  }, [handleFile])

  const toggleCard = useCallback((i: number) => {
    setExpandedCards(prev => { const n = new Set(prev); n.has(i) ? n.delete(i) : n.add(i); return n })
  }, [])

  const allTickets = candidates.flatMap(c => c.relatedTickets ?? [])

  const NavItem = ({ v, icon: Icon, label, count }: { v: View; icon: React.ComponentType<{ size?: number }>; label: string; count?: number }) => (
    <div onClick={() => setView(v)} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '7px 8px', borderRadius: 8, fontSize: 13, cursor: 'pointer', background: view === v ? 'rgba(232,130,74,0.15)' : 'transparent', border: `0.5px solid ${view === v ? 'rgba(232,130,74,0.3)' : 'transparent'}`, color: view === v ? '#E8824A' : '#7A7875' }}>
      <Icon size={14} />
      {label}
      {count !== undefined && <span style={{ marginLeft: 'auto', fontSize: 10, fontFamily: "'DM Mono', monospace", background: 'rgba(255,255,255,0.06)', padding: '2px 6px', borderRadius: 10, color: '#7A7875' }}>{count}</span>}
    </div>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
      {/* Topbar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', height: 48, borderBottom: '0.5px solid rgba(255,255,255,0.07)', background: '#111113', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <Logo />
          <a href="/landing" style={{ fontSize: 11, color: '#7A7875', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4 }}>
            <ExternalLink size={11} /> Landing page
          </a>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {candidates.length > 0 && (
            <div style={{ display: 'flex', gap: 4 }}>
              {(['markdown', 'json', 'csv'] as const).map(fmt => (
                <button key={fmt} onClick={() => exportResult(fmt)} style={{ fontSize: 10, fontFamily: "'DM Mono', monospace", padding: '4px 8px', borderRadius: 5, background: 'rgba(255,255,255,0.04)', border: '0.5px solid rgba(255,255,255,0.1)', color: '#7A7875', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Download size={10} />{fmt}
                </button>
              ))}
            </div>
          )}
          <span style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", padding: '3px 8px', borderRadius: 4, border: '0.5px solid rgba(255,255,255,0.12)', color: '#7A7875' }}>alpha · acme-corp</span>
          {dataLoaded && <span style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", padding: '3px 8px', borderRadius: 4, background: 'rgba(93,170,120,0.12)', border: '0.5px solid rgba(93,170,120,0.25)', color: '#5DAA78' }}>✓ {signals.length} signals</span>}
        </div>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Sidebar */}
        <div style={{ width: 200, flexShrink: 0, background: '#0E0E10', borderRight: '0.5px solid rgba(255,255,255,0.07)', display: 'flex', flexDirection: 'column', padding: '12px 8px', gap: 2 }}>
          <span style={{ fontSize: 10, fontFamily: "'DM Mono', monospace", color: '#7A7875', letterSpacing: '0.08em', textTransform: 'uppercase' as const, padding: '8px 8px 4px' }}>Workspace</span>
          <NavItem v="discovery" icon={Zap} label="Discovery" count={candidates.length || undefined} />
          <NavItem v="signals" icon={BarChart2} label="Signals" count={signals.length || undefined} />
          <NavItem v="tickets" icon={Ticket} label="Dev Tickets" count={allTickets.length || undefined} />

          <span style={{ fontSize: 10, fontFamily: "'DM Mono', monospace", color: '#7A7875', letterSpacing: '0.08em', textTransform: 'uppercase' as const, padding: '16px 8px 4px' }}>Sources</span>
          {[['Interviews', 'interview'], ['Feedback CSV', 'csv'], ['JSON export', 'json']].map(([label, type]) => (
            <div key={label} onClick={() => fileRef.current?.click()} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '7px 8px', borderRadius: 8, fontSize: 13, color: '#7A7875', cursor: 'pointer' }}>
              <FileText size={14} />
              {label}
              <span style={{ marginLeft: 'auto', fontSize: 10, color: '#5DAA78' }}>{uploading ? '…' : dataLoaded ? '✓' : '+'}</span>
            </div>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

          {/* DISCOVERY */}
          {view === 'discovery' && (
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <div style={{ padding: '20px 24px 0', flexShrink: 0 }}>
                <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22 }}>Product Discovery</div>
                <div style={{ fontSize: 12, color: '#7A7875', marginTop: 3 }}>Ask what to build. Get ranked features backed by your users' own words.</div>
              </div>

              {/* Upload / sample zone */}
              {!dataLoaded && (
                <div ref={dropRef} style={{ margin: '16px 24px 0', padding: 20, background: '#18181B', border: '0.5px dashed rgba(255,255,255,0.1)', borderRadius: 12, textAlign: 'center' as const, cursor: 'pointer', transition: 'border-color 0.2s' }} onClick={() => fileRef.current?.click()}>
                  <input ref={fileRef} type="file" accept=".csv,.txt,.json" style={{ display: 'none' }} onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f) }} />
                  <Upload size={22} color="#7A7875" style={{ margin: '0 auto 8px' }} />
                  <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Drop interview transcript, CSV, or JSON export</div>
                  <div style={{ fontSize: 11, color: '#7A7875', marginBottom: 14 }}>Intercom · Gong · Amplitude · G2 · plain text</div>
                  <button onClick={e => { e.stopPropagation(); loadSampleData() }} style={{ padding: '7px 16px', borderRadius: 7, background: 'rgba(232,130,74,0.15)', border: '0.5px solid rgba(232,130,74,0.3)', color: '#E8824A', cursor: 'pointer', fontSize: 12 }}>
                    {uploading ? 'Loading…' : 'Or load sample dataset →'}
                  </button>
                </div>
              )}

              {/* Ask box */}
              <div style={{ margin: '14px 24px 0', flexShrink: 0 }}>
                <div style={{ fontSize: 11, color: '#7A7875', fontFamily: "'DM Mono', monospace", marginBottom: 8 }}>// ask forge anything about your product</div>
                <div style={{ background: '#18181B', border: '0.5px solid rgba(255,255,255,0.12)', borderRadius: 12, overflow: 'hidden' }}>
                  <textarea
                    value={question}
                    onChange={e => setQuestion(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); runAnalysis() } }}
                    placeholder="What should we build next quarter?"
                    style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', color: '#F2F0EB', fontFamily: "'Instrument Sans', system-ui, sans-serif", fontSize: 14, padding: '12px 16px 8px', resize: 'none', height: 60 }}
                  />
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 12px', borderTop: '0.5px solid rgba(255,255,255,0.07)' }}>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' as const }}>
                      {['What to build next?', 'Why churning?', 'Enterprise blockers?'].map(q => (
                        <button key={q} onClick={() => setQuestion(q)} style={{ fontSize: 11, padding: '3px 8px', borderRadius: 4, background: 'rgba(255,255,255,0.04)', color: '#7A7875', border: '0.5px solid rgba(255,255,255,0.07)', cursor: 'pointer' }}>{q}</button>
                      ))}
                    </div>
                    <button onClick={runAnalysis} disabled={streaming || !question.trim()} style={{ fontSize: 12, fontWeight: 500, padding: '6px 16px', borderRadius: 8, background: '#E8824A', color: '#1A0E06', border: 'none', cursor: streaming || !question.trim() ? 'not-allowed' : 'pointer', opacity: streaming || !question.trim() ? 0.6 : 1 }}>
                      {streaming ? 'Analyzing…' : 'Analyze →'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              {(streaming || statusMsg) && (
                <div style={{ padding: '10px 24px 0', flexShrink: 0 }}>
                  {streaming && <div style={{ height: 2, background: '#18181B', borderRadius: 1, overflow: 'hidden', marginBottom: 6 }}><div className="animate-shimmer" style={{ height: '100%' }} /></div>}
                  <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7A7875' }}>{statusMsg}</div>
                </div>
              )}

              {error && (
                <div style={{ margin: '10px 24px 0', padding: '10px 14px', background: 'rgba(212,107,107,0.1)', border: '0.5px solid rgba(212,107,107,0.3)', borderRadius: 8, fontSize: 12, color: '#D46B6B', display: 'flex', gap: 8 }}>
                  <AlertTriangle size={13} style={{ flexShrink: 0, marginTop: 1 }} />{error}
                </div>
              )}

              {/* Results */}
              <div style={{ flex: 1, overflowY: 'auto', padding: '14px 24px 24px' }}>
                {candidates.length > 0 && (
                  <>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                      <span style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7A7875', textTransform: 'uppercase' as const, letterSpacing: '0.07em' }}>Top Recommendations</span>
                      {result && <span style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7A7875' }}>{result.signalCount} signals · {result.processingMs}ms</span>}
                    </div>
                    {candidates.map((c, i) => <CandidateCard key={c.id} candidate={c} index={i} isExpanded={expandedCards.has(i)} onToggle={() => toggleCard(i)} />)}
                    {result?.themesSurfaced && result.themesSurfaced.length > 0 && (
                      <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' as const, marginTop: 8 }}>
                        <span style={{ fontSize: 10, color: '#7A7875', fontFamily: "'DM Mono', monospace" }}>themes:</span>
                        {result.themesSurfaced.slice(0, 8).map(t => <span key={t} style={pill('#7A7875', 'rgba(122,120,117,0.08)', 'rgba(255,255,255,0.07)')}>{t}</span>)}
                      </div>
                    )}
                  </>
                )}
                {candidates.length === 0 && !streaming && !error && (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '80%', gap: 12, opacity: 0.35 }}>
                    <Zap size={30} color="#7A7875" />
                    <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 18 }}>No analysis yet</div>
                    <div style={{ fontSize: 13, color: '#7A7875', textAlign: 'center' as const, maxWidth: 280, lineHeight: 1.6 }}>Load your data and ask a question. Forge surfaces what your users actually want built.</div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* SIGNALS */}
          {view === 'signals' && (
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22, marginBottom: 4 }}>Signal Feed</div>
              <div style={{ fontSize: 12, color: '#7A7875', marginBottom: 20 }}>Every quote, complaint, and request — tagged and searchable.</div>
              {signals.length === 0 ? (
                <div style={{ textAlign: 'center' as const, padding: 40, opacity: 0.35 }}>
                  <BarChart2 size={28} color="#7A7875" style={{ margin: '0 auto 12px' }} />
                  <div style={{ fontSize: 13, color: '#7A7875' }}>No signals. Load data from Discovery.</div>
                </div>
              ) : signals.map((sig, i) => (
                <div key={sig.id ?? i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: '0.5px solid rgba(255,255,255,0.07)' }}>
                  <span style={{ ...pill('#7A7875', 'rgba(122,120,117,0.08)', 'rgba(255,255,255,0.07)'), minWidth: 70, textAlign: 'center' as const }}>{sig.sourceType}</span>
                  <span style={{ fontSize: 13, color: '#F2F0EB', flex: 1, fontStyle: 'italic', lineHeight: 1.4 }}>"{sig.normalizedText}"</span>
                  <span style={pill(SENTIMENT_COLOR[sig.sentiment] ?? '#7A7875', (SENTIMENT_COLOR[sig.sentiment] ?? '#7A7875') + '22', (SENTIMENT_COLOR[sig.sentiment] ?? '#7A7875') + '55')}>{sig.sentiment}</span>
                  {sig.themes.slice(0, 2).map(t => <span key={t} style={pill('#7A7875', 'rgba(122,120,117,0.06)', 'rgba(255,255,255,0.07)')}>{t}</span>)}
                </div>
              ))}
            </div>
          )}

          {/* TICKETS */}
          {view === 'tickets' && (
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22 }}>Dev Tickets</div>
                {allTickets.length > 0 && <button onClick={() => exportResult('csv')} style={{ fontSize: 11, padding: '5px 12px', borderRadius: 7, background: 'rgba(255,255,255,0.04)', border: '0.5px solid rgba(255,255,255,0.1)', color: '#7A7875', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}><Download size={11} /> Export CSV</button>}
              </div>
              <div style={{ fontSize: 12, color: '#7A7875', marginBottom: 20 }}>AI-generated specs, ready for Cursor or Claude Code.</div>
              {allTickets.length === 0 ? (
                <div style={{ textAlign: 'center' as const, padding: 40, opacity: 0.35 }}>
                  <Ticket size={28} color="#7A7875" style={{ margin: '0 auto 12px' }} />
                  <div style={{ fontSize: 13, color: '#7A7875' }}>No tickets yet — run an analysis in Discovery.</div>
                </div>
              ) : (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 8 }}>
                  {allTickets.map(t => <TicketCard key={t.id} ticket={t} />)}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
