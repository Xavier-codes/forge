import { NextRequest, NextResponse } from 'next/server'
import { parseInterviewTranscript, parseFeedbackCSV, parseJSONExport } from '@/lib/lib/ingestion'
import { deduplicateSignals } from '@/lib/lib/scorer'
import { SignalSource } from '@/lib/types'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { type, content, sourceType, userId, userSegment } = body

    if (!type || !content) {
      return NextResponse.json({ error: 'type and content are required' }, { status: 400 })
    }

    let result
    switch (type) {
      case 'interview':
        result = parseInterviewTranscript(content, { userId, userSegment })
        break
      case 'csv':
        result = parseFeedbackCSV(content, (sourceType as SignalSource) ?? 'intercom')
        break
      case 'json':
        result = parseJSONExport(content, (sourceType as SignalSource) ?? 'intercom')
        break
      default:
        return NextResponse.json({ error: `Unknown type: ${type}` }, { status: 400 })
    }

    const deduped = deduplicateSignals(result.signalsParsed)

    return NextResponse.json({
      signalsExtracted: deduped.length,
      signals: deduped.map(s => ({ ...s, createdAt: s.createdAt.toISOString() })),
      errors: result.errors,
      durationMs: result.durationMs,
    })
  } catch (err) {
    console.error('[/api/ingest]', err)
    return NextResponse.json({ error: 'Ingestion failed', detail: String(err) }, { status: 500 })
  }
}
