import { NextRequest, NextResponse } from 'next/server'
import { Forge } from '@/lib'
import Anthropic from '@anthropic-ai/sdk'

export const runtime = 'nodejs'
export const maxDuration = 30

const client = new Anthropic()

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { question, signals: rawSignals, useAI = true } = body

    if (!question || typeof question !== 'string') {
      return NextResponse.json({ error: 'question is required' }, { status: 400 })
    }

    // Run the deterministic Forge engine first
    const forge = new Forge('web-session')
    if (rawSignals && Array.isArray(rawSignals)) {
      // Signals already parsed by /api/ingest — add directly
      const signals = rawSignals.map((s: any) => ({
        ...s,
        createdAt: new Date(s.createdAt),
      }))
      forge.addSignals(signals)
    }

    const engineResult = forge.analyze(question, 5)

    // If we have signals and AI is enabled, enrich with Claude
    let aiEnrichment = null
    if (useAI && engineResult.candidates.length > 0) {
      const candidateSummaries = engineResult.candidates.map((c, i) => ({
        rank: i + 1,
        title: c.title,
        evidenceSummary: c.evidenceSummary,
        topQuotes: c.supportingSignals.slice(0, 3).map(s => s.normalizedText),
        impactScore: c.impactScore,
        priorityScore: c.priorityScore,
        effort: c.effortEstimate,
      }))

      const prompt = `You are an expert product manager at a YC-backed B2B SaaS company.

A PM asked: "${question}"

The Forge signal analysis engine found these top feature candidates from ${engineResult.signalCount} user signals:

${JSON.stringify(candidateSummaries, null, 2)}

For each candidate, write:
1. A compelling 2-sentence "PM verdict" explaining WHY this should be built NOW (business impact, urgency)
2. One "watch out" — the biggest risk or assumption that needs validation

Respond ONLY with valid JSON array (no markdown, no preamble):
[{"rank": 1, "verdict": "...", "watchOut": "..."}, ...]`

      const aiResponse = await client.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }],
      })

      const aiText = aiResponse.content.find(b => b.type === 'text')?.text ?? '[]'
      try {
        aiEnrichment = JSON.parse(aiText.replace(/```json|```/g, '').trim())
      } catch {
        aiEnrichment = null
      }
    }

    // Merge AI enrichment into candidates
    const enrichedCandidates = engineResult.candidates.map((c, i) => {
      const ai = aiEnrichment?.find((a: any) => a.rank === i + 1)
      return {
        ...c,
        supportingSignals: c.supportingSignals.map(s => ({
          ...s,
          createdAt: s.createdAt.toISOString(),
        })),
        relatedTickets: c.relatedTickets?.map(t => ({
          ...t,
          createdAt: t.createdAt.toISOString(),
        })),
        pmVerdict: ai?.verdict ?? null,
        watchOut: ai?.watchOut ?? null,
      }
    })

    return NextResponse.json({
      candidates: enrichedCandidates,
      signalCount: engineResult.signalCount,
      themesSurfaced: engineResult.themesSurfaced,
      processingMs: engineResult.processingMs,
      query: engineResult.query,
    })
  } catch (err) {
    console.error('[/api/analyze]', err)
    return NextResponse.json({ error: 'Analysis failed', detail: String(err) }, { status: 500 })
  }
}
