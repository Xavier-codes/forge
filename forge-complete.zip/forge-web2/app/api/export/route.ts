/**
 * /api/export
 *
 * Export analysis results in multiple formats.
 * Supports: markdown report, JSON (full data), CSV (tickets only)
 */

import { NextRequest, NextResponse } from 'next/server'
import { formatResultAsMarkdown } from '@/lib/lib/engine'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { format, result, question } = body

  if (!result || !format) {
    return NextResponse.json({ error: 'format and result are required' }, { status: 400 })
  }

  const timestamp = new Date().toISOString().slice(0, 10)

  switch (format) {
    case 'markdown': {
      // Reconstruct AnalysisResult with Date objects
      const reconstructed = {
        ...result,
        candidates: result.candidates.map((c: Record<string, unknown>) => ({
          ...c,
          supportingSignals: (c.supportingSignals as Record<string, unknown>[]).map(s => ({ ...s, createdAt: new Date(s.createdAt as string) })),
          relatedTickets: ((c.relatedTickets as Record<string, unknown>[]) ?? []).map(t => ({ ...t, createdAt: new Date(t.createdAt as string) })),
        })),
        query: { question: question ?? 'Analysis', workspaceId: 'export' },
        createdAt: new Date(),
        modelVersion: 'forge-v1',
        processingMs: result.processingMs ?? 0,
        themesSurfaced: result.themesSurfaced ?? [],
        signalCount: result.signalCount ?? 0,
      }

      // Build enriched markdown
      let md = formatResultAsMarkdown(reconstructed)

      // Append AI verdicts if present
      result.candidates.forEach((c: Record<string, unknown>, i: number) => {
        if (c.pmVerdict || c.watchOut) {
          const section = `\n### AI Verdict — ${c.title}\n\n`
          const verdict = c.pmVerdict ? `**PM Verdict:** ${c.pmVerdict}\n\n` : ''
          const watchOut = c.watchOut ? `**Watch out:** ${c.watchOut}\n\n` : ''
          md += section + verdict + watchOut
        }
      })

      return new Response(md, {
        headers: {
          'Content-Type': 'text/markdown; charset=utf-8',
          'Content-Disposition': `attachment; filename="forge-analysis-${timestamp}.md"`,
        },
      })
    }

    case 'json': {
      const json = JSON.stringify(result, null, 2)
      return new Response(json, {
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="forge-analysis-${timestamp}.json"`,
        },
      })
    }

    case 'csv': {
      const tickets = result.candidates.flatMap((c: Record<string, unknown>) =>
        ((c.relatedTickets as Record<string, unknown>[]) ?? []).map(t => ({
          id: t.id,
          feature: c.title,
          type: t.type,
          title: t.title,
          labels: (t.labels as string[]).join(';'),
          estimatedHours: t.estimatedHours ?? '',
          status: t.status,
          acceptanceCriteria: (t.acceptanceCriteria as string[]).join(' | '),
        }))
      )

      const headers = ['id', 'feature', 'type', 'title', 'labels', 'estimatedHours', 'status', 'acceptanceCriteria']
      const rows = tickets.map((t: Record<string, unknown>) =>
        headers.map(h => `"${String(t[h] ?? '').replace(/"/g, '""')}"`).join(',')
      )
      const csv = [headers.join(','), ...rows].join('\n')

      return new Response(csv, {
        headers: {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': `attachment; filename="forge-tickets-${timestamp}.csv"`,
        },
      })
    }

    default:
      return NextResponse.json({ error: `Unknown format: ${format}` }, { status: 400 })
  }
}
