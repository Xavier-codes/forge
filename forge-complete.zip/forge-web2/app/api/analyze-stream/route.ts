/**
 * /api/analyze-stream
 *
 * Streaming version of the analysis endpoint.
 * 1. Runs the deterministic Forge engine (sync, instant)
 * 2. Streams Claude's PM verdict + watch-out for each candidate via SSE
 *
 * Client reads Server-Sent Events:
 *   data: {"type":"engine","payload":{...engineResult}}
 *   data: {"type":"enrich","candidateId":"...","pmVerdict":"...","watchOut":"..."}
 *   data: {"type":"token","candidateId":"...","field":"pmVerdict","token":"..."}
 *   data: {"type":"done"}
 */

import { NextRequest } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { Forge } from '@/lib'

export const runtime = 'nodejs'
export const maxDuration = 60

const client = new Anthropic()

function sse(data: unknown): string {
  return `data: ${JSON.stringify(data)}\n\n`
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { question, signals: rawSignals } = body

  if (!question?.trim()) {
    return new Response('question required', { status: 400 })
  }

  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: unknown) => controller.enqueue(encoder.encode(sse(data)))

      try {
        // ── 1. Run Forge engine (sync) ──────────────────────────────────
        send({ type: 'status', message: 'Clustering signals…' })

        const forge = new Forge('stream-session')
        if (Array.isArray(rawSignals)) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          forge.addSignals(rawSignals.map((s: any) => ({
            ...s,
            createdAt: new Date(s.createdAt as string),
          })))
        }

        const engineResult = forge.analyze(question, 5)

        send({ type: 'status', message: `Scored ${engineResult.signalCount} signals — ${engineResult.candidates.length} features found` })

        // Send engine result immediately so UI can render candidates
        send({
          type: 'engine',
          payload: {
            ...engineResult,
            candidates: engineResult.candidates.map(c => ({
              ...c,
              supportingSignals: c.supportingSignals.map(s => ({ ...s, createdAt: s.createdAt.toISOString() })),
              relatedTickets: c.relatedTickets?.map(t => ({ ...t, createdAt: t.createdAt.toISOString() })),
            })),
          },
        })

        // ── 2. Stream Claude enrichment per candidate ───────────────────
        send({ type: 'status', message: 'Getting Claude\'s PM verdict…' })

        for (const candidate of engineResult.candidates) {
          const quotes = candidate.supportingSignals
            .filter(s => ['pain', 'churn_risk', 'request'].includes(s.sentiment))
            .slice(0, 4)
            .map(s => `- [${s.sourceType}/${s.sentiment}] "${s.normalizedText}"`)
            .join('\n')

          const prompt = `You are a senior PM at a YC-backed B2B SaaS company. Be direct, specific, and commercially minded.

Feature candidate: "${candidate.title}"
Priority score: ${candidate.priorityScore}/100
Impact category: ${candidate.impactCategory}
Evidence: ${candidate.evidenceSummary}

User signals:
${quotes}

The PM asked: "${question}"

Write exactly two things:
VERDICT: (2 sentences) Why this feature should be built NOW. Be specific about the business impact and urgency. Name the mechanism — is it retention, deal velocity, activation rate?
WATCHOUT: (1 sentence) The single biggest assumption or risk that could make this the wrong thing to build.

Format: output only the two labeled lines, nothing else.`

          let verdictText = ''
          let watchoutText = ''
          let currentField: 'pmVerdict' | 'watchOut' | null = null

          try {
            const claudeStream = client.messages.stream({
              model: 'claude-sonnet-4-20250514',
              max_tokens: 300,
              messages: [{ role: 'user', content: prompt }],
            })

            for await (const event of claudeStream) {
              if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') {
                const token = event.delta.text

                // Detect which field we're in based on accumulated text
                verdictText += token
                if (verdictText.includes('VERDICT:') && !verdictText.includes('WATCHOUT:')) {
                  currentField = 'pmVerdict'
                } else if (verdictText.includes('WATCHOUT:')) {
                  currentField = 'watchOut'
                }

                send({ type: 'token', candidateId: candidate.id, field: currentField ?? 'pmVerdict', token })
              }
            }

            // Parse the completed response by splitting on labels
            const verdictIdx = verdictText.indexOf('VERDICT:')
            const watchoutIdx = verdictText.indexOf('WATCHOUT:')
            const pmVerdict = verdictIdx >= 0
              ? (watchoutIdx > verdictIdx ? verdictText.slice(verdictIdx + 8, watchoutIdx) : verdictText.slice(verdictIdx + 8)).trim()
              : ''
            const watchOut = watchoutIdx >= 0
              ? verdictText.slice(watchoutIdx + 9).trim()
              : ''

            send({
              type: 'enrich',
              candidateId: candidate.id,
              pmVerdict,
              watchOut,
            })
          } catch (claudeErr) {
            // Claude failed for this candidate — skip enrichment, don't crash
            console.error(`Claude enrichment failed for ${candidate.id}:`, claudeErr)
            send({ type: 'enrich', candidateId: candidate.id, pmVerdict: '', watchOut: '' })
          }
        }

        send({ type: 'done' })
      } catch (err) {
        send({ type: 'error', message: String(err) })
      } finally {
        controller.close()
      }
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  })
}
