# Forge — Web Application

The full Forge product: a Next.js web app with a React frontend and two API routes powered by the Forge signal-scoring engine + Claude.

## Stack

- **Next.js 16** (App Router, TypeScript)
- **Forge engine** (`/lib/`) — the signal scoring, ingestion, and ticket generation library
- **Anthropic SDK** — Claude enriches each feature candidate with a PM verdict and risk flag
- **Zero UI library dependencies** — all CSS via inline styles + CSS variables

## Running locally

```bash
cp .env.example .env.local
# Add your ANTHROPIC_API_KEY to .env.local

npm install
npm run dev
# → http://localhost:3000
```

## API routes

### `POST /api/ingest`

Parse raw text into signals.

```json
{
  "type": "interview" | "csv" | "json",
  "content": "<raw text>",
  "sourceType": "intercom" | "g2" | "sales_call" | ...,
  "userId": "optional",
  "userSegment": "enterprise" | "smb" | "free"
}
```

Returns: `{ signalsExtracted, signals[], errors[], durationMs }`

### `POST /api/analyze`

Run the full analysis pipeline.

```json
{
  "question": "What should I build next quarter?",
  "signals": [...],   // signals from /api/ingest
  "useAI": true       // set false to skip Claude enrichment
}
```

Returns: `{ candidates[], signalCount, themesSurfaced[], processingMs }`

Each candidate includes:
- `priorityScore`, `impactScore`, `effortEstimate`, `riskScore`
- `supportingSignals` with quotes
- `relatedTickets` with acceptance criteria and code pointers
- `pmVerdict` — Claude's 2-sentence business case (when useAI: true)
- `watchOut` — Claude's top risk flag (when useAI: true)

## Deploying to Vercel

```bash
npx vercel deploy
# Set ANTHROPIC_API_KEY in Vercel dashboard → Settings → Environment Variables
```

## Architecture

```
app/
├── page.tsx              Main React app (Discovery, Signals, Tickets views)
├── layout.tsx            Root layout + fonts
├── globals.css           Design tokens (CSS variables)
└── api/
    ├── analyze/route.ts  Forge engine + Claude enrichment
    └── ingest/route.ts   Multi-source parser endpoint

lib/                      Forge core library (copied from /forge package)
├── index.ts              Forge fluent builder API
├── types/index.ts        All type definitions
└── lib/
    ├── ingestion.ts      Parsers + sentiment classifier + theme extractor
    ├── scorer.ts         Impact / reach / risk / priority scoring
    ├── ticketGenerator.ts Theme-matched dev ticket templates
    ├── engine.ts         Main orchestrator
    └── utils.ts          Pure utilities
```
