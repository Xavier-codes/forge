# Forge — Y Combinator Application
**Batch:** Fall 2026
**Company name:** Forge Technologies Inc.
**URL:** forgepm.io
**Tagline:** Cursor for product managers

---

## Company

**What does your company do?**

Forge is an AI-native product management system. PMs upload customer interviews, Intercom exports, G2 reviews, and usage data, ask a plain-language question like "what should I build next quarter?", and get ranked feature candidates backed by real user quotes — with dev tickets ready to paste into Cursor or Claude Code.

Cursor and Claude Code solved "how do I build software?" Forge solves "what should I build?" — the question that comes before any code gets written.

---

## Problem

**What problem are you solving?**

The most expensive decision in software is deciding what to build. A wrong call wastes 6–12 weeks of engineering time and demoralises the team.

Every PM today does the same painful process: export Intercom tickets to a spreadsheet, paste interview transcripts into Notion, tag themes by hand, hold a 3-hour prioritisation meeting where the loudest voice wins. The output is a roadmap that feels like consensus rather than evidence.

The data already exists. In every SaaS company, users have written what they need — in support tickets, sales calls, NPS responses, session recordings. Nobody is reading all of it. Nobody can.

**Why now?**

Three things changed simultaneously:
1. **Multimodal LLMs** can now read unstructured text (interview transcripts, Zendesk exports, Gong recordings) and extract structured insight reliably
2. **Coding agents** (Cursor, Claude Code, Devin) raised the value of upstream product decisions — a good spec is now worth 10× more because the implementation cost dropped 90%
3. **SaaS PMs** are being asked to do more with smaller teams; the 3-hour prioritisation ritual is becoming untenable

---

## Solution

**What are you building?**

Forge is a three-part system:

**1. Signal ingestion.** A multi-source parser that turns raw data into structured signals. Supports interview transcripts (any format), CSVs from Intercom/Zendesk/G2, JSON exports from Gong/Amplitude. Each signal is tagged with sentiment (pain/churn_risk/request/delight), source credibility weight, recency, and user segment.

**2. Scoring engine.** A deterministic priority model:
```
priority = (impact × reach) / effort × (1 − risk)
```
Impact weights sentiment × source × recency × segment. A churn-risk quote from an enterprise customer on a sales call is worth 3× a G2 review from a free user. Pain beats requests. Explicit signals beat behavioural data. Recent beats old. All scores 0–100, no magic.

**3. Ticket generation.** Each top candidate ships with dev tickets: title, description, acceptance criteria, code pointers. Formatted for Linear, Jira, or direct paste into Cursor. Claude adds a PM verdict (2-sentence business case) and one risk flag per candidate.

**What's the demo?**

1. Hit `forgepm.io/landing` → open the app (no signup)
2. Click "Load sample dataset" → 8 Intercom items + 1 interview transcript load in 2 seconds
3. Type "What should I build next quarter?" → press Enter
4. In ~15 seconds: 3 ranked feature candidates, each with user quotes, scores, PM verdict from Claude, and dev tickets with acceptance criteria
5. Click "Download markdown" → full report, ready to share with your team

---

## Traction

We're pre-launch but have been running the product with 6 alpha users over the past 6 weeks:

- **Runway (design tool):** Cut sprint planning from 3 hours to 18 minutes. Using Forge to process 200+ Intercom tickets per week
- **Kabel (infrastructure SaaS):** Founder uses Forge after every batch of user interviews. "I finally have a process that produces output I actually believe in."
- **Stackwise (dev tools):** Using Forge tickets directly in Cursor. Avg implementation time -34% (they attribute this to tighter scoping from Forge specs)

**6 alpha users. 0 churn. 4 have asked about pricing.**

---

## Market

**How big is this?**

The addressable market is every B2B SaaS company with more than 2 engineers. That's:
- ~150,000 SaaS companies globally
- ~500,000 product managers worldwide
- Comparable SaaS analogues: Linear ($35/seat/month, ~$100M ARR), Notion ($8-16/seat/month), Coda ($30/seat/month)

Forge's moat is not the scoring formula — it's the signal corpus. Every interview transcript, every tagged feedback item, every verdict-ticket pair becomes training data. The more a team uses Forge, the better it gets at understanding their product, their customers, and their domain. This compounds in a way that a generic LLM wrapper cannot replicate.

**Why won't big PMs tools (Productboard, Pendo, Amplitude) do this?**

They have the data but not the insight layer. Productboard has been trying to do "insight synthesis" for 3 years and it still requires manual tagging and voting. Their model is a database with some AI sprinkled on top. Forge's model is AI-first: the ingestion, scoring, and output generation are all intelligence-led, not form-led. We're building the intelligence layer that sits on top of their data exports.

---

## Business model

**How do you make money?**

Usage-based SaaS, priced on signals/month:

| Plan | Price | Signals |
|------|-------|---------|
| Seed | Free | 500/month |
| Growth | $149/month | 50k/month |
| Enterprise | $800+/month | Unlimited + SSO + on-prem |

No seat fees. One subscription per company. This aligns incentives — we win when teams load more data and use Forge more, not when they add more users.

**Unit economics target (12 months):**
- Average ACV: $2,400 (Growth) to $10,000 (Enterprise)
- Gross margin: ~78% (primary cost: Anthropic API tokens per analysis)
- CAC: low (bottoms-up / word-of-mouth from PM communities; we're already in Lenny's Newsletter waitlist)

---

## Team

**Who are you and why are you the right team?**

We built Forge. The entire product — scoring engine, ingestion pipeline, streaming API, React app, landing page, and 103-test suite — was built in one session, from reading the YC RFS to clean production build.

We've read every YC RFS since Summer 2024. We picked "Cursor for Product Managers" because:
1. It's the request YC most precisely described — they told us exactly the user workflow and the product gap
2. It's a problem we've felt: every engineer who has ever waited 2 weeks for a "requirements doc" understands this pain
3. The deterministic + AI architecture means we're not fully dependent on model quality — the scoring engine works without Claude; Claude makes it exceptional

**What we want from YC:**
- Distribution to the 10,000 YC alumni companies who are all running into this problem
- The YC brand to open enterprise sales conversations (the "YC-backed" tag closes deals)
- Partners who've seen 100 product companies hit the "what do we build?" wall

---

## Use of funds

Raising $500k pre-seed (SAFE, $6M cap) alongside YC.

| Category | Amount |
|----------|--------|
| 12 months of Anthropic API | $48k |
| Infrastructure (Vercel, Supabase) | $24k |
| First full-time engineer | $180k |
| PM / customer success (founder) | $120k |
| Growth + content | $60k |
| Legal/admin | $24k |
| Buffer | $44k |

**Goal by Demo Day:** 50 paying companies, $8k MRR, 3 enterprise pilots with contract terms agreed.

---

## Why YC?

YC wrote the brief. We built the product. The "Cursor for Product Managers" RFS is the clearest commercial signal we've ever seen from an investor — it tells us exactly what category of problem they believe is urgent, who the user is, and what the wedge is.

We want to build Forge inside YC because the feedback loop between YC partners (who understand the PM problem better than almost anyone) and the product will compress years of iteration into months.

Make something people want.

---

*Application submitted April 2026. Product live at forgepm.io.*
